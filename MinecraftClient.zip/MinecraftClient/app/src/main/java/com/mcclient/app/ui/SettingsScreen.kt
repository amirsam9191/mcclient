package com.mcclient.app.ui

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import com.mcclient.app.Core
import com.mcclient.app.game.ChatParser
import com.mcclient.app.ui.mc.Assets
import com.mcclient.app.ui.mc.McFont
import com.mcclient.app.ui.mc.McText
import java.io.File

@SuppressLint("BatteryLife")
fun requestIgnoreBattery(ctx: Context) {
    try {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(ctx.packageName)) {
            ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName)))
        }
    } catch (e: Exception) {
        try { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e2: Exception) { /* ignore */ }
    }
}

private fun importFont(ctx: Context, uri: Uri) {
    try {
        val dir = File(ctx.filesDir, "fonts")
        dir.mkdirs()
        val f = File(dir, "persian.ttf")
        ctx.contentResolver.openInputStream(uri)?.use { ins -> f.outputStream().use { ins.copyTo(it) } }
        try {
            Typeface.createFromFile(f)
        } catch (e: Exception) {
            f.delete()
            Toast.makeText(ctx, "فایل فونت معتبر نیست", Toast.LENGTH_SHORT).show()
            return
        }
        McFont.reload(ctx)
        Toast.makeText(ctx, "فونت فارسی اعمال شد", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(ctx, "خطا در خواندن فونت", Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun SettingSwitch(label: String, hint: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label)
            if (hint != null) Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = Core.prefs
    var name by remember { mutableStateOf(prefs.username) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importFont(ctx, uri)
    }
    val sample = remember {
        ChatParser.legacy("\u00A7a\u0633\u0644\u0627\u0645 \u00A7fSteve\u00A77: \u00A7fHello \u062F\u0646\u06CC\u0627 123 \u0645\u0627\u06CC\u0646\u06A9\u0631\u0627\u0641\u062A \u06F1\u06F2\u06F3")
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت") }
            Text("تنظیمات", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        SettingSwitch(
            "حالت سرورلیست",
            "روشن: لیست سرورها مثل ماینکرافت. خاموش: دو کادر آی‌پی و نام کاربری.",
            prefs.serverListMode
        ) { prefs.setServerListMode(it) }

        OutlinedTextField(
            value = name,
            onValueChange = { name = it; prefs.setUsername(it.trim()) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("نام کاربری پیش‌فرض") },
            textStyle = LocalTextStyle.current.copy(textDirection = TextDirection.Ltr)
        )

        SettingSwitch("ریسپاون خودکار", "بعد از مرگ به‌صورت خودکار ریسپاون می‌شود.", prefs.autoRespawn) { prefs.setAutoRespawn(it) }

        HorizontalDivider()
        Text("نمایش متن چت", fontWeight = FontWeight.Bold)
        Text("اندازهٔ متن: ${"%.1f".format(prefs.chatScale)}x", style = MaterialTheme.typography.bodySmall)
        Slider(value = prefs.chatScale, onValueChange = { prefs.setChatScale((Math.round(it * 10) / 10f)) }, valueRange = 0.7f..2.0f)
        Text("اندازهٔ فونت فارسی پیکسلی: ${prefs.persianPx}", style = MaterialTheme.typography.bodySmall)
        Slider(
            value = prefs.persianPx.toFloat(),
            onValueChange = { prefs.setPersianPx(Math.round(it)); McFont.reload(ctx) },
            valueRange = 8f..16f,
            steps = 7
        )
        Box(Modifier.fillMaxWidth().background(Color(0xCC000000)).padding(4.dp)) { McText(sample) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("وارد کردن فونت فارسی (TTF)") }
            OutlinedButton(onClick = {
                File(ctx.filesDir, "fonts/persian.ttf").delete()
                McFont.reload(ctx)
            }) { Text("فونت پیش‌فرض") }
        }
        Text(
            "برای ظاهر پیکسلی ماینکرافتی، یک فونت فارسی پیکسلی (TTF) وارد کنید. بدون آن، فونت سیستم با رندر پیکسلی نمایش داده می‌شود.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        HorizontalDivider()
        Text("فونت و تکسچرهای ماینکرافت", fontWeight = FontWeight.Bold)
        Text(
            Assets.status.ifEmpty { if (Assets.has(ctx)) "آماده است" else "دانلود نشده" },
            style = MaterialTheme.typography.bodySmall
        )
        if (Assets.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        else OutlinedButton(onClick = {
            val app = ctx.applicationContext
            Thread { Assets.download(app) }.start()
        }) { Text(if (Assets.has(ctx)) "دانلود دوباره" else "دانلود از Mojang") }

        HorizontalDivider()
        Text("اجرای دائمی در پس‌زمینه", fontWeight = FontWeight.Bold)
        Text(
            "برای اینکه اتصال با بسته شدن صفحه قطع نشود، اجازهٔ نادیده گرفتن بهینه‌سازی باتری لازم است.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        OutlinedButton(onClick = { requestIgnoreBattery(ctx) }) { Text("اجازهٔ اجرای دائمی") }
    }
}
