package com.mcclient.app.game

import com.mcclient.app.net.Json
import org.json.JSONTokener

object McColors {
    val WHITE = 0xFFFFFFFF.toInt()
    val GRAY = 0xFFAAAAAA.toInt()
    val RED = 0xFFFF5555.toInt()
    val GREEN = 0xFF55FF55.toInt()
    val YELLOW = 0xFFFFFF55.toInt()

    val LEGACY = intArrayOf(
        0xFF000000.toInt(), 0xFF0000AA.toInt(), 0xFF00AA00.toInt(), 0xFF00AAAA.toInt(),
        0xFFAA0000.toInt(), 0xFFAA00AA.toInt(), 0xFFFFAA00.toInt(), 0xFFAAAAAA.toInt(),
        0xFF555555.toInt(), 0xFF5555FF.toInt(), 0xFF55FF55.toInt(), 0xFF55FFFF.toInt(),
        0xFFFF5555.toInt(), 0xFFFF55FF.toInt(), 0xFFFFFF55.toInt(), 0xFFFFFFFF.toInt()
    )
    val NAMED: Map<String, Int> = mapOf(
        "black" to LEGACY[0], "dark_blue" to LEGACY[1], "dark_green" to LEGACY[2], "dark_aqua" to LEGACY[3],
        "dark_red" to LEGACY[4], "dark_purple" to LEGACY[5], "gold" to LEGACY[6], "gray" to LEGACY[7],
        "dark_gray" to LEGACY[8], "blue" to LEGACY[9], "green" to LEGACY[10], "aqua" to LEGACY[11],
        "red" to LEGACY[12], "light_purple" to LEGACY[13], "yellow" to LEGACY[14], "white" to LEGACY[15]
    )
}

data class ChatSpan(
    val text: String,
    val color: Int = McColors.WHITE,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val underline: Boolean = false,
    val strike: Boolean = false,
    val obfuscated: Boolean = false
)

class ChatLine(val id: Long, val spans: List<ChatSpan>) {
    val plain: String = spans.joinToString("") { it.text }
}

/** Turns NBT/JSON text components (and legacy section-sign strings) into flat styled spans. */
object ChatParser {
    private data class St(
        val color: Int = McColors.WHITE,
        val bold: Boolean = false,
        val italic: Boolean = false,
        val underline: Boolean = false,
        val strike: Boolean = false,
        val obf: Boolean = false
    )

    fun fromAny(n: Any?): List<ChatSpan> {
        val out = ArrayList<ChatSpan>()
        try {
            flatten(n, St(), out)
        } catch (e: Exception) {
            out.add(ChatSpan(n.toString()))
        }
        return out.filter { it.text.isNotEmpty() }
    }

    fun plain(n: Any?): String = fromAny(n).joinToString("") { it.text }

    fun legacy(s: String): List<ChatSpan> {
        val o = ArrayList<ChatSpan>()
        addLegacy(s, St(), o)
        return o
    }

    /** For JSON text as sent in the login phase and in status responses. */
    fun fromJsonText(s: String): List<ChatSpan> {
        val t = s.trim()
        if (t.isEmpty()) return emptyList()
        return try {
            if (t[0] == '{' || t[0] == '[' || t[0] == '"') fromAny(Json.toAny(JSONTokener(t).nextValue())) else legacy(t)
        } catch (e: Exception) {
            legacy(t)
        }
    }

    fun plainFromJsonText(s: String): String = fromJsonText(s).joinToString("") { it.text }

    @Suppress("UNCHECKED_CAST")
    private fun flatten(node: Any?, st: St, out: MutableList<ChatSpan>) {
        when (node) {
            null -> {}
            is String -> addLegacy(node, st, out)
            is Number, is Boolean -> addLegacy(node.toString(), st, out)
            is List<*> -> for (e in node) flatten(e, st, out)
            is Map<*, *> -> {
                val m = node as Map<String, Any?>
                val s = style(m, st)
                when {
                    m.containsKey("text") -> addLegacy(m["text"]?.toString() ?: "", s, out)
                    m.containsKey("translate") -> translate(m, s, out)
                    m.containsKey("keybind") -> addLegacy(m["keybind"].toString(), s, out)
                    m.containsKey("selector") -> addLegacy(m["selector"].toString(), s, out)
                    m.containsKey("score") -> {
                        val sc = m["score"] as? Map<*, *>
                        addLegacy(sc?.get("value")?.toString() ?: "", s, out)
                    }
                }
                (m["extra"] as? List<*>)?.forEach { flatten(it, s, out) }
            }
            else -> addLegacy(node.toString(), st, out)
        }
    }

    private fun flag(v: Any?, cur: Boolean): Boolean = when (v) {
        null -> cur
        is Boolean -> v
        is Number -> v.toInt() != 0
        is String -> v == "true"
        else -> cur
    }

    private fun parseColor(s: String): Int? =
        if (s.startsWith("#") && s.length == 7) s.substring(1).toIntOrNull(16)?.let { 0xFF000000.toInt() or it }
        else McColors.NAMED[s]

    private fun style(m: Map<String, Any?>, st: St): St {
        var c = st.color
        val cs = m["color"] as? String
        if (cs != null) c = parseColor(cs) ?: c
        return st.copy(
            color = c,
            bold = flag(m["bold"], st.bold),
            italic = flag(m["italic"], st.italic),
            underline = flag(m["underlined"], st.underline),
            strike = flag(m["strikethrough"], st.strike),
            obf = flag(m["obfuscated"], st.obf)
        )
    }

    private fun translate(m: Map<String, Any?>, s: St, out: MutableList<ChatSpan>) {
        val key = m["translate"].toString()
        val args = (m["with"] as? List<*>) ?: emptyList<Any?>()
        val fmt = Translations.map[key] ?: (m["fallback"] as? String)
        if (fmt == null) {
            addLegacy(key, s, out)
            for (a in args) { addLegacy(" ", s, out); flatten(a, s, out) }
            return
        }
        val sb = StringBuilder()
        var auto = 0
        var i = 0
        fun flushText() {
            if (sb.isNotEmpty()) { addLegacy(sb.toString(), s, out); sb.setLength(0) }
        }
        while (i < fmt.length) {
            val c = fmt[i]
            if (c == '%' && i + 1 < fmt.length) {
                if (fmt[i + 1] == '%') { sb.append('%'); i += 2; continue }
                var j = i + 1
                var n = 0
                var has = false
                while (j < fmt.length && fmt[j].isDigit()) { n = n * 10 + (fmt[j] - '0'); j++; has = true }
                if (has && j < fmt.length && fmt[j] == '$') j++
                if (j < fmt.length && fmt[j] == 's') {
                    flushText()
                    val idx = if (has) n - 1 else auto++
                    if (idx >= 0 && idx < args.size) flatten(args[idx], s, out)
                    i = j + 1
                    continue
                }
            }
            sb.append(c)
            i++
        }
        flushText()
    }

    private fun addLegacy(text: String, st: St, out: MutableList<ChatSpan>) {
        if (text.isEmpty()) return
        var cur = st
        val sb = StringBuilder()
        fun flush() {
            if (sb.isNotEmpty()) {
                out.add(ChatSpan(sb.toString(), cur.color, cur.bold, cur.italic, cur.underline, cur.strike, cur.obf))
                sb.setLength(0)
            }
        }
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (c == '\u00A7' && i + 1 < text.length) {
                val code = text[i + 1].lowercaseChar()
                val ci = "0123456789abcdef".indexOf(code)
                if (ci >= 0) {
                    flush(); cur = St(color = McColors.LEGACY[ci])
                } else when (code) {
                    'l' -> { flush(); cur = cur.copy(bold = true) }
                    'o' -> { flush(); cur = cur.copy(italic = true) }
                    'n' -> { flush(); cur = cur.copy(underline = true) }
                    'm' -> { flush(); cur = cur.copy(strike = true) }
                    'k' -> { flush(); cur = cur.copy(obf = true) }
                    'r' -> { flush(); cur = St() }
                    else -> {}
                }
                i += 2
                continue
            }
            sb.append(c)
            i++
        }
        flush()
    }
}

/** English vanilla translations for the keys that show up in everyday chat. Unknown keys render as the key itself. */
object Translations {
    val map: Map<String, String> = mapOf(
        "chat.type.text" to "<%s> %s",
        "chat.type.text.narrate" to "%s says %s",
        "chat.type.emote" to "* %s %s",
        "chat.type.announcement" to "[%s] %s",
        "chat.type.admin" to "[%s: %s]",
        "chat.type.team.text" to "%s <%s> %s",
        "chat.type.team.sent" to "-> %s <%s> %s",
        "chat.type.team.hover" to "Message Team",
        "commands.message.display.incoming" to "%s whispers to you: %s",
        "commands.message.display.outgoing" to "You whisper to %s: %s",
        "chat.type.advancement.task" to "%s has made the advancement %s",
        "chat.type.advancement.goal" to "%s has reached the goal %s",
        "chat.type.advancement.challenge" to "%s has completed the challenge %s",
        "multiplayer.player.joined" to "%s joined the game",
        "multiplayer.player.joined.renamed" to "%s (formerly known as %s) joined the game",
        "multiplayer.player.left" to "%s left the game",
        "multiplayer.disconnect.kicked" to "Kicked by an operator",
        "multiplayer.disconnect.banned" to "You are banned from this server",
        "multiplayer.disconnect.banned.reason" to "You are banned from this server.\nReason: %s",
        "multiplayer.disconnect.server_shutdown" to "Server closed",
        "multiplayer.disconnect.not_whitelisted" to "You are not white-listed on this server!",
        "multiplayer.disconnect.duplicate_login" to "You logged in from another location",
        "multiplayer.disconnect.idling" to "You have been idle for too long!",
        "multiplayer.disconnect.flying" to "Flying is not enabled on this server",
        "multiplayer.disconnect.name_taken" to "That name is already taken",
        "multiplayer.disconnect.server_full" to "The server is full!",
        "multiplayer.disconnect.invalid_player_movement" to "Invalid move player packet received",
        "multiplayer.disconnect.chat_validation_failed" to "Chat message validation failure",
        "multiplayer.disconnect.too_many_pending_chats" to "Too many unacknowledged chat messages",
        "multiplayer.disconnect.unsigned_chat" to "Received chat packet with missing or invalid signature.",
        "multiplayer.disconnect.incompatible" to "Incompatible client! Please use %s",
        "disconnect.timeout" to "Timed out",
        "disconnect.spam" to "Kicked for spamming",
        "disconnect.kicked" to "Was kicked from the game",
        "disconnect.disconnected" to "Disconnected",
        "disconnect.lost" to "Connection Lost",
        "death.attack.generic" to "%1\$s died",
        "death.attack.player" to "%1\$s was slain by %2\$s",
        "death.attack.mob" to "%1\$s was slain by %2\$s",
        "death.attack.fall" to "%1\$s hit the ground too hard",
        "death.attack.lava" to "%1\$s tried to swim in lava",
        "death.attack.drown" to "%1\$s drowned",
        "death.attack.explosion" to "%1\$s blew up",
        "death.attack.arrow" to "%1\$s was shot by %2\$s",
        "death.attack.onFire" to "%1\$s burned to death",
        "death.attack.inFire" to "%1\$s went up in flames",
        "death.attack.outOfWorld" to "%1\$s fell out of the world",
        "death.attack.starve" to "%1\$s starved to death",
        "death.attack.magic" to "%1\$s was killed by magic",
        "death.attack.cactus" to "%1\$s was pricked to death",
        "death.fell.accident.generic" to "%1\$s fell from a high place",
        "commands.gamemode.success.self" to "Set own game mode to %s",
        "gameMode.survival" to "Survival Mode",
        "gameMode.creative" to "Creative Mode",
        "gameMode.adventure" to "Adventure Mode",
        "gameMode.spectator" to "Spectator Mode"
    )
}
