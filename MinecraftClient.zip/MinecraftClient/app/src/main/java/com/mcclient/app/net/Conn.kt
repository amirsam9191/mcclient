package com.mcclient.app.net

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import com.mcclient.app.game.ChatParser
import com.mcclient.app.game.ChatSpan
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.zip.Deflater
import java.util.zip.Inflater

class Incoming(val id: Int, val r: PacketReader)

/** Minecraft packet framing with optional zlib compression. Thread-safe for sending. */
class Conn(private val input: InputStream, private val output: OutputStream) {
    @Volatile var threshold: Int = -1
    private val wlock = Any()
    private val inflater = Inflater()
    private val deflater = Deflater()

    private fun readVarIntStream(): Int {
        var r = 0
        var shift = 0
        while (true) {
            val b = input.read()
            if (b < 0) throw EOFException("connection closed")
            r = r or ((b and 0x7F) shl shift)
            if ((b and 0x80) == 0) return r
            shift += 7
            if (shift > 35) throw IOException("bad varint")
        }
    }

    private fun readFully(n: Int): ByteArray {
        val buf = ByteArray(n)
        var off = 0
        while (off < n) {
            val k = input.read(buf, off, n - off)
            if (k < 0) throw EOFException("connection closed")
            off += k
        }
        return buf
    }

    fun read(): Incoming {
        val len = readVarIntStream()
        if (len <= 0 || len > 16 * 1024 * 1024) throw IOException("bad packet length $len")
        val data = readFully(len)
        var payload = data
        if (threshold >= 0) {
            val r = PacketReader(data)
            val dataLen = r.varInt()
            payload = if (dataLen == 0) data.copyOfRange(r.pos, data.size) else inflate(data, r.pos, dataLen)
        }
        val pr = PacketReader(payload)
        val id = pr.varInt()
        return Incoming(id, pr)
    }

    private fun inflate(src: ByteArray, off: Int, expected: Int): ByteArray {
        if (expected < 0 || expected > 16 * 1024 * 1024) throw IOException("bad uncompressed size")
        inflater.reset()
        inflater.setInput(src, off, src.size - off)
        val out = ByteArray(expected)
        var n = 0
        while (n < expected) {
            val k = inflater.inflate(out, n, expected - n)
            if (k == 0 && (inflater.finished() || inflater.needsInput() || inflater.needsDictionary())) break
            n += k
        }
        if (n != expected) throw IOException("corrupt compressed packet")
        return out
    }

    private fun deflate(src: ByteArray): ByteArray {
        deflater.reset()
        deflater.setInput(src)
        deflater.finish()
        val bos = ByteArrayOutputStream(src.size / 2 + 16)
        val buf = ByteArray(4096)
        while (!deflater.finished()) {
            val k = deflater.deflate(buf)
            bos.write(buf, 0, k)
        }
        return bos.toByteArray()
    }

    private fun vi(v: Int): ByteArray = PacketWriter().varInt(v).toByteArray()

    fun send(id: Int, body: ByteArray = ByteArray(0)) {
        val payload = PacketWriter().varInt(id).bytes(body).toByteArray()
        synchronized(wlock) {
            if (threshold >= 0) {
                if (payload.size >= threshold) {
                    val comp = deflate(payload)
                    val dl = vi(payload.size)
                    output.write(vi(dl.size + comp.size))
                    output.write(dl)
                    output.write(comp)
                } else {
                    output.write(vi(1 + payload.size))
                    output.write(0)
                    output.write(payload)
                }
            } else {
                output.write(vi(payload.size))
                output.write(payload)
            }
            output.flush()
        }
    }
}

object Address {
    const val DEFAULT_PORT = 25565

    /** "host", "host:port", "[ipv6]" or "[ipv6]:port" -> (host, port). Missing port => 25565. */
    fun parse(input: String): Pair<String, Int> {
        val t = input.trim()
        if (t.startsWith("[")) {
            val e = t.indexOf(']')
            if (e > 0) {
                val port = t.substring(e + 1).removePrefix(":").toIntOrNull() ?: DEFAULT_PORT
                return Pair(t.substring(1, e), port)
            }
        }
        val first = t.indexOf(':')
        val last = t.lastIndexOf(':')
        if (first >= 0 && first == last) {
            val p = t.substring(first + 1).toIntOrNull()
            val host = t.substring(0, first)
            return Pair(host, if (p != null && p in 1..65535) p else DEFAULT_PORT)
        }
        return Pair(t, DEFAULT_PORT)
    }
}

data class PingResult(
    val ok: Boolean,
    val motd: List<ChatSpan> = emptyList(),
    val online: Int = 0,
    val max: Int = 0,
    val version: String = "",
    val pingMs: Long = -1,
    val icon: Bitmap? = null,
    val error: String = ""
)

object ServerPinger {
    fun ping(address: String): PingResult {
        var result = PingResult(false)
        val s = Socket()
        try {
            val (host, port) = Address.parse(address)
            s.connect(InetSocketAddress(host, port), 5000)
            s.soTimeout = 5000
            val c = Conn(s.getInputStream(), s.getOutputStream())
            c.send(0x00, PacketWriter().varInt(765).string(host).short(port).varInt(1).toByteArray())
            c.send(0x00)
            val resp = c.read()
            if (resp.id != 0x00) {
                result = PingResult(false, error = "پاسخ نامعتبر")
            } else {
                val json = JSONObject(resp.r.string())
                val motd = ChatParser.fromAny(Json.toAny(json.opt("description")))
                val players = json.optJSONObject("players")
                val version = json.optJSONObject("version")?.optString("name", "") ?: ""
                var icon: Bitmap? = null
                val fav = json.optString("favicon", "")
                if (fav.startsWith("data:image")) {
                    try {
                        val b = Base64.decode(fav.substringAfter(","), Base64.DEFAULT)
                        icon = BitmapFactory.decodeByteArray(b, 0, b.size)
                    } catch (e: Exception) { /* ignore broken icon */ }
                }
                val t0 = System.nanoTime()
                c.send(0x01, PacketWriter().long(t0).toByteArray())
                c.read()
                val ms = (System.nanoTime() - t0) / 1_000_000
                result = PingResult(true, motd, players?.optInt("online", 0) ?: 0, players?.optInt("max", 0) ?: 0, version, ms, icon)
            }
        } catch (e: Exception) {
            result = PingResult(false, error = e.message ?: e.javaClass.simpleName)
        } finally {
            try { s.close() } catch (e: Exception) { /* ignore */ }
        }
        return result
    }
}
