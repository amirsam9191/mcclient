package com.mcclient.app.game

import android.content.Context
import com.mcclient.app.Core
import com.mcclient.app.data.PackMode
import com.mcclient.app.data.ServerEntry
import com.mcclient.app.net.Address
import com.mcclient.app.net.Conn
import com.mcclient.app.net.Incoming
import com.mcclient.app.net.PacketReader
import com.mcclient.app.net.PacketWriter
import com.mcclient.app.net.ParseException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.EOFException
import java.net.ConnectException
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

class KickException(val reason: String) : RuntimeException(reason)

enum class Status { IDLE, CONNECTING, ONLINE, WAITING_RECONNECT }
enum class Proto { LOGIN, CONFIG, PLAY }

class PackOffer(
    val id: UUID,
    val url: String,
    val hash: String,
    val forced: Boolean,
    val prompt: String,
    val inConfig: Boolean
)

class Suggestions(val start: Int, val length: Int, val items: List<String>)

data class SessionState(
    val status: Status = Status.IDLE,
    val serverName: String = "",
    val info: String = "",
    val health: Float = 20f,
    val food: Int = 20,
    val reconnectIn: Int = 0,
    val actionBar: List<ChatSpan> = emptyList(),
    val actionBarNonce: Int = 0,
    val players: List<String> = emptyList(),
    val pendingPack: PackOffer? = null,
    val suggestions: Suggestions? = null
)

/**
 * Minecraft Java 1.20.4 (protocol 765) offline-mode client session.
 * Packet ids come from the verified protocol 765 tables (see README).
 */
class Session(private val ctx: Context) {
    companion object {
        const val PROTOCOL = 765
        // Serverbound (play)
        const val SB_CONFIRM_TELEPORT = 0x00
        const val SB_ACK_MESSAGE = 0x03
        const val SB_CHAT_COMMAND = 0x04
        const val SB_CHAT_MESSAGE = 0x05
        const val SB_CHUNK_BATCH_RECEIVED = 0x07
        const val SB_CLIENT_STATUS = 0x08
        const val SB_SUGGESTIONS_REQUEST = 0x0A
        const val SB_ACK_CONFIGURATION = 0x0B
        const val SB_KEEP_ALIVE = 0x15
        const val SB_POS_ROT = 0x18
        const val SB_PONG = 0x24
        const val SB_PACK_RESPONSE = 0x28
        // Clientbound (play)
        const val CB_CHUNK_BATCH_FINISHED = 0x0C
        const val CB_SUGGESTIONS = 0x10
        const val CB_DISCONNECT = 0x1B
        const val CB_DISGUISED_CHAT = 0x1C
        const val CB_KEEP_ALIVE = 0x24
        const val CB_LOGIN = 0x29
        const val CB_PING = 0x33
        const val CB_PLAYER_CHAT = 0x37
        const val CB_COMBAT_DEATH = 0x3A
        const val CB_PLAYER_INFO_REMOVE = 0x3B
        const val CB_PLAYER_INFO_UPDATE = 0x3C
        const val CB_SYNC_POSITION = 0x3E
        const val CB_ADD_PACK = 0x44
        const val CB_RESPAWN = 0x45
        const val CB_ACTION_BAR = 0x4A
        const val CB_SET_HEALTH = 0x5B
        const val CB_START_CONFIG = 0x67
        const val CB_SYSTEM_CHAT = 0x69
    }

    private val _state = MutableStateFlow(SessionState())
    val state: StateFlow<SessionState> = _state.asStateFlow()
    private val _chat = MutableStateFlow<List<ChatLine>>(emptyList())
    val chat: StateFlow<List<ChatLine>> = _chat.asStateFlow()

    private val ids = AtomicLong(0)
    @Volatile private var stopRequested = false
    @Volatile private var thread: Thread? = null
    @Volatile private var conn: Conn? = null
    @Volatile private var socket: Socket? = null
    @Volatile private var proto = Proto.LOGIN
    @Volatile private var executor: ScheduledExecutorService? = null

    // Per-connection game data (touched mostly from the reader thread).
    private var chatTypes = HashMap<Int, Pair<String, List<String>>>()
    private val players = LinkedHashMap<UUID, String>()
    private var px = 0.0
    private var py = 0.0
    private var pz = 0.0
    private var yaw = 0f
    private var pitch = 0f
    @Volatile private var hasPos = false
    private var schedulerStarted = false
    private var respawnPending = false
    private var pendingAck = 0
    @Volatile private var suggestId = 0

    // All socket writes that originate from the UI go through this thread (Android forbids network I/O on the main thread).
    private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "mc-io").also { it.isDaemon = true } }

    private fun setState(f: (SessionState) -> SessionState) { _state.update(f) }

    // ---------------------------------------------------------------- public API

    @Synchronized
    fun connect(server: ServerEntry, username: String) {
        val old = thread
        if (old != null && old.isAlive) {
            if (!stopRequested) return
            try { old.join(2000) } catch (e: InterruptedException) { /* ignore */ }
        }
        stopRequested = false
        _chat.value = emptyList()
        Core.lastEnd = ""
        _state.value = SessionState(
            status = Status.CONNECTING,
            serverName = server.name.ifBlank { server.address },
            info = "در حال اتصال…"
        )
        val t = Thread({ supervise(server, username) }, "mc-session")
        t.isDaemon = true
        thread = t
        t.start()
    }

    fun disconnect() {
        stopRequested = true
        thread?.interrupt()
        io.execute { try { socket?.close() } catch (e: Exception) { /* ignore */ } }
    }

    /** Sends a chat message, or a command when the text starts with "/". Returns false when not connected. */
    fun sendUserText(text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty()) return false
        if (conn == null || proto != Proto.PLAY) return false
        io.execute {
            try { if (t.startsWith("/")) sendCommand(t.substring(1)) else sendMessage(t) } catch (e: Exception) { /* ignore */ }
        }
        return true
    }

    fun respawn() {
        io.execute {
            try { conn?.send(SB_CLIENT_STATUS, PacketWriter().varInt(0).toByteArray()) } catch (e: Exception) { /* ignore */ }
        }
    }

    fun clearSuggestions() { setState { it.copy(suggestions = null) } }

    fun requestSuggestions(text: String) {
        io.execute { requestSuggestionsNow(text) }
    }

    private fun requestSuggestionsNow(text: String) {
        val c = conn
        if (c == null || proto != Proto.PLAY || _state.value.status != Status.ONLINE || text.isEmpty()) {
            clearSuggestions(); return
        }
        try {
            if (text.startsWith("/")) {
                val tid = ++suggestId
                c.send(SB_SUGGESTIONS_REQUEST, PacketWriter().varInt(tid).string(text).toByteArray())
            } else {
                val start = text.lastIndexOf(' ') + 1
                val word = text.substring(start)
                if (word.isEmpty()) { clearSuggestions(); return }
                val names = synchronized(players) { players.values.toList() }
                    .filter { it.startsWith(word, ignoreCase = true) && !it.equals(word, ignoreCase = true) }
                    .sorted()
                setState { it.copy(suggestions = if (names.isEmpty()) null else Suggestions(start, word.length, names)) }
            }
        } catch (e: Exception) { /* ignore */ }
    }

    fun answerPack(accept: Boolean) {
        val offer = _state.value.pendingPack ?: return
        setState { it.copy(pendingPack = null) }
        if (accept) startPackDownload(offer) else io.execute { respondPack(offer, 1) }
    }

    // ---------------------------------------------------------------- supervisor (auto-rejoin)

    private fun supervise(server: ServerEntry, username: String) {
        var endReason = ""
        try {
            outer@ while (!stopRequested) {
                setState { it.copy(status = Status.CONNECTING, info = "در حال اتصال به ${server.address}…", reconnectIn = 0) }
                endReason = try {
                    runConnection(server, username)
                    "ارتباط با سرور بسته شد"
                } catch (e: KickException) {
                    "از سرور بیرون انداخته شدید: ${e.reason}"
                } catch (e: Exception) {
                    if (stopRequested) "" else describe(e)
                }
                if (stopRequested) break
                addSystem(endReason, McColors.RED)
                if (!server.autoRejoin) break
                for (s in 5 downTo 1) {
                    setState { it.copy(status = Status.WAITING_RECONNECT, reconnectIn = s, info = endReason) }
                    try { Thread.sleep(1000) } catch (e: InterruptedException) { break@outer }
                    if (stopRequested) break@outer
                }
            }
        } finally {
            try { socket?.close() } catch (e: Exception) { /* ignore */ }
            Core.lastEnd = if (stopRequested) "" else endReason
            _state.value = SessionState()
            thread = null
        }
    }

    private fun describe(e: Exception): String = when (e) {
        is UnknownHostException -> "آدرس سرور پیدا نشد"
        is ConnectException -> "اتصال به سرور برقرار نشد (سرور خاموش است یا پورت اشتباه است)"
        is SocketTimeoutException -> "زمان اتصال به سرور تمام شد"
        is EOFException, is SocketException -> "ارتباط با سرور قطع شد"
        else -> "خطا: ${e.message ?: e.javaClass.simpleName}"
    }

    // ---------------------------------------------------------------- one connection

    private fun resetConnectionData() {
        chatTypes = HashMap()
        synchronized(players) { players.clear() }
        hasPos = false
        schedulerStarted = false
        respawnPending = false
        pendingAck = 0
        suggestId = 0
    }

    private fun runConnection(server: ServerEntry, username: String) {
        resetConnectionData()
        val (host, port) = Address.parse(server.address)
        val sock = Socket()
        sock.tcpNoDelay = true
        sock.keepAlive = true
        sock.connect(InetSocketAddress(host, port), 10_000)
        sock.soTimeout = 45_000
        socket = sock
        val c = Conn(sock.getInputStream(), sock.getOutputStream())
        conn = c
        proto = Proto.LOGIN
        try {
            c.send(0x00, PacketWriter().varInt(PROTOCOL).string(host).short(port).varInt(2).toByteArray())
            val offline = UUID.nameUUIDFromBytes("OfflinePlayer:$username".toByteArray(Charsets.UTF_8))
            c.send(0x00, PacketWriter().string(username).uuid(offline).toByteArray())
            while (!stopRequested) {
                val p = c.read()
                try {
                    when (proto) {
                        Proto.LOGIN -> onLogin(c, p)
                        Proto.CONFIG -> onConfig(c, p, server)
                        Proto.PLAY -> onPlay(c, p, server)
                    }
                } catch (e: ParseException) {
                    // A packet we could not parse is skipped; the connection stays alive.
                }
            }
        } finally {
            executor?.shutdownNow()
            executor = null
            try { sock.close() } catch (e: Exception) { /* ignore */ }
            conn = null
            socket = null
        }
    }

    private fun onLogin(c: Conn, p: Incoming) {
        val r = p.r
        when (p.id) {
            0x00 -> throw KickException(ChatParser.plainFromJsonText(r.string()))
            0x01 -> throw KickException("این سرور آنلاین‌مود است و به حساب اصلی نیاز دارد. این نسخه فقط سرورهای آفلاین‌مود را پشتیبانی می‌کند.")
            0x02 -> {
                c.send(0x03) // Login Acknowledged
                proto = Proto.CONFIG
                c.send(0x00, PacketWriter().string("en_us").byte(8).varInt(0).bool(true).byte(0x7F).varInt(1).bool(false).bool(true).toByteArray())
                c.send(0x01, PacketWriter().string("minecraft:brand").string("vanilla").toByteArray())
            }
            0x03 -> c.threshold = r.varInt()
            0x04 -> { val id = r.varInt(); c.send(0x02, PacketWriter().varInt(id).bool(false).toByteArray()) }
        }
    }

    private fun onConfig(c: Conn, p: Incoming, server: ServerEntry) {
        val r = p.r
        when (p.id) {
            0x01 -> throw KickException(ChatParser.plain(r.nbt()))
            0x02 -> { c.send(0x02); proto = Proto.PLAY }
            0x03 -> c.send(0x03, PacketWriter().long(r.long()).toByteArray())
            0x04 -> c.send(0x04, PacketWriter().int(r.int()).toByteArray())
            0x05 -> parseRegistry(r)
            0x07 -> onPackOffer(r, true, server)
        }
    }

    private fun parseRegistry(r: PacketReader) {
        val root = r.nbt() as? Map<*, *> ?: return
        val reg = root["minecraft:chat_type"] as? Map<*, *> ?: return
        val values = reg["value"] as? List<*> ?: return
        val map = HashMap<Int, Pair<String, List<String>>>()
        for ((index, e) in values.withIndex()) {
            val m = e as? Map<*, *> ?: continue
            val id = (m["id"] as? Number)?.toInt() ?: index
            val chat = (m["element"] as? Map<*, *>)?.get("chat") as? Map<*, *> ?: continue
            val key = chat["translation_key"] as? String ?: continue
            val params = (chat["parameters"] as? List<*>)?.map { it.toString() } ?: listOf("sender", "content")
            map[id] = Pair(key, params)
        }
        chatTypes = map
    }

    private fun onPlay(c: Conn, p: Incoming, server: ServerEntry) {
        val r = p.r
        when (p.id) {
            CB_CHUNK_BATCH_FINISHED -> c.send(SB_CHUNK_BATCH_RECEIVED, PacketWriter().float(10f).toByteArray())
            CB_KEEP_ALIVE -> c.send(SB_KEEP_ALIVE, PacketWriter().long(r.long()).toByteArray())
            CB_PING -> c.send(SB_PONG, PacketWriter().int(r.int()).toByteArray())
            CB_DISCONNECT -> throw KickException(ChatParser.plain(r.nbt()))
            CB_LOGIN -> {
                executor?.shutdownNow()
                executor = null
                schedulerStarted = false
                hasPos = false
                respawnPending = false
                setState { it.copy(status = Status.ONLINE, info = "متصل شد", health = 20f, food = 20) }
                addSystem("به سرور وارد شدید", McColors.GREEN)
            }
            CB_SYNC_POSITION -> {
                val x = r.double(); val y = r.double(); val z = r.double()
                val yw = r.float(); val pt = r.float()
                val flags = r.byte()
                val tid = r.varInt()
                px = if ((flags and 0x01) != 0) px + x else x
                py = if ((flags and 0x02) != 0) py + y else y
                pz = if ((flags and 0x04) != 0) pz + z else z
                yaw = if ((flags and 0x08) != 0) yaw + yw else yw
                pitch = if ((flags and 0x10) != 0) pitch + pt else pt
                hasPos = true
                c.send(SB_CONFIRM_TELEPORT, PacketWriter().varInt(tid).toByteArray())
                sendPosition(c)
                if (!schedulerStarted) {
                    schedulerStarted = true
                    startScheduler(server)
                }
            }
            CB_SET_HEALTH -> {
                val hp = r.float()
                val food = r.varInt()
                setState { it.copy(health = hp, food = food) }
                if (hp <= 0f) autoRespawn() else respawnPending = false
            }
            CB_COMBAT_DEATH -> autoRespawn()
            CB_RESPAWN -> respawnPending = false
            CB_SYSTEM_CHAT -> {
                val content = r.nbt()
                val overlay = r.bool()
                if (overlay) showActionBar(ChatParser.fromAny(content)) else addLine(ChatParser.fromAny(content))
            }
            CB_ACTION_BAR -> showActionBar(ChatParser.fromAny(r.nbt()))
            CB_DISGUISED_CHAT -> {
                val message = r.nbt()
                val ct = r.varInt()
                val sender = r.nbt()
                val target = if (r.bool()) r.nbt() else null
                addLine(formatChat(ct, sender, message, target))
            }
            CB_PLAYER_CHAT -> {
                r.uuid(); r.varInt()
                val hasSig = r.bool()
                if (hasSig) r.skip(256)
                val msg = r.string()
                r.long(); r.long()
                val prev = r.varInt()
                for (i in 0 until prev) { val id = r.varInt(); if (id == 0) r.skip(256) }
                val unsigned = if (r.bool()) r.nbt() else null
                val filter = r.varInt()
                if (filter == 2) { val n = r.varInt(); r.skip(n * 8) }
                val ct = r.varInt()
                val sender = r.nbt()
                val target = if (r.bool()) r.nbt() else null
                if (hasSig) {
                    pendingAck++
                    if (pendingAck >= 20) {
                        c.send(SB_ACK_MESSAGE, PacketWriter().varInt(pendingAck).toByteArray())
                        pendingAck = 0
                    }
                }
                addLine(formatChat(ct, sender, unsigned ?: msg, target))
            }
            CB_PLAYER_INFO_UPDATE -> {
                val actions = r.ubyte()
                val count = r.varInt()
                for (i in 0 until count) {
                    val uuid = r.uuid()
                    var name: String? = null
                    if ((actions and 0x01) != 0) {
                        name = r.string()
                        val props = r.varInt()
                        for (k in 0 until props) { r.string(); r.string(); if (r.bool()) r.string() }
                    }
                    if ((actions and 0x02) != 0) {
                        if (r.bool()) { r.uuid(); r.long(); r.skip(r.varInt()); r.skip(r.varInt()) }
                    }
                    if ((actions and 0x04) != 0) r.varInt()
                    if ((actions and 0x08) != 0) r.bool()
                    if ((actions and 0x10) != 0) r.varInt()
                    if ((actions and 0x20) != 0) { if (r.bool()) r.nbt() }
                    if (name != null) synchronized(players) { players[uuid] = name }
                }
                publishPlayers()
            }
            CB_PLAYER_INFO_REMOVE -> {
                val n = r.varInt()
                for (i in 0 until n) { val u = r.uuid(); synchronized(players) { players.remove(u) } }
                publishPlayers()
            }
            CB_SUGGESTIONS -> {
                val tid = r.varInt()
                val start = r.varInt()
                val len = r.varInt()
                val n = r.varInt()
                val items = ArrayList<String>()
                for (i in 0 until n) { items.add(r.string()); if (r.bool()) r.nbt() }
                if (tid == suggestId) setState { it.copy(suggestions = if (items.isEmpty()) null else Suggestions(start, len, items)) }
            }
            CB_ADD_PACK -> onPackOffer(r, false, server)
            CB_START_CONFIG -> {
                c.send(SB_ACK_CONFIGURATION)
                proto = Proto.CONFIG
                hasPos = false
            }
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun formatChat(ct: Int, sender: Any?, content: Any?, target: Any?): List<ChatSpan> {
        val info = chatTypes[ct]
        val key = info?.first ?: "chat.type.text"
        val params = info?.second ?: listOf("sender", "content")
        val args = ArrayList<Any?>()
        for (p in params) {
            args.add(when (p) { "sender" -> sender; "content" -> content; "target" -> target ?: ""; else -> "" })
        }
        val node = LinkedHashMap<String, Any?>()
        node["translate"] = key
        node["with"] = args
        return ChatParser.fromAny(node)
    }

    private fun publishPlayers() {
        val names = synchronized(players) { players.values.toList() }.sortedBy { it.lowercase() }
        setState { it.copy(players = names) }
    }

    private fun addLine(spans: List<ChatSpan>) {
        if (spans.isEmpty()) return
        val line = ChatLine(ids.incrementAndGet(), spans)
        _chat.update { (it + line).takeLast(1000) }
    }

    private fun addSystem(text: String, color: Int) {
        addLine(listOf(ChatSpan(text, color)))
    }

    private fun showActionBar(spans: List<ChatSpan>) {
        setState { it.copy(actionBar = spans, actionBarNonce = it.actionBarNonce + 1) }
    }

    private fun autoRespawn() {
        if (respawnPending) return
        if (Core.prefs.autoRespawn) {
            respawnPending = true
            addSystem("مُردید؛ ریسپاون خودکار…", McColors.YELLOW)
            respawn()
        } else {
            addSystem("مُردید؛ برای ادامه دکمهٔ ریسپاون را بزنید", McColors.YELLOW)
        }
    }

    private fun sendPosition(c: Conn) {
        c.send(SB_POS_ROT, PacketWriter().double(px).double(py).double(pz).float(yaw).float(pitch).bool(true).toByteArray())
    }

    private fun sendMessage(text: String) {
        val t = if (text.length > 256) text.substring(0, 256) else text
        val c = conn ?: return
        c.send(
            SB_CHAT_MESSAGE,
            PacketWriter().string(t).long(System.currentTimeMillis()).long(0L).bool(false).varInt(0)
                .bytes(ByteArray(3)).toByteArray()
        )
    }

    private fun sendCommand(cmd: String) {
        val t = if (cmd.length > 256) cmd.substring(0, 256) else cmd
        val c = conn ?: return
        c.send(
            SB_CHAT_COMMAND,
            PacketWriter().string(t).long(System.currentTimeMillis()).long(0L).varInt(0).varInt(0)
                .bytes(ByteArray(3)).toByteArray()
        )
    }

    /** Position keep-alive, auto-login and the per-server startup commands run on one scheduler per join. */
    private fun startScheduler(server: ServerEntry) {
        val ex = Executors.newSingleThreadScheduledExecutor()
        executor = ex
        ex.scheduleAtFixedRate({
            try {
                val c = conn
                if (hasPos && proto == Proto.PLAY && c != null) sendPosition(c)
            } catch (e: Exception) { /* connection loss is handled by the reader */ }
        }, 1000, 1000, TimeUnit.MILLISECONDS)

        var base = 0L
        if (server.autoLogin && server.password.isNotEmpty()) {
            ex.schedule(Runnable {
                try { sendCommand("login " + server.password) } catch (e: Exception) { /* ignore */ }
            }, 1500, TimeUnit.MILLISECONDS)
            base = 2500L
        }
        for (cmd in server.commands) {
            if (cmd.command.isBlank()) continue
            ex.schedule(Runnable {
                try {
                    val t = cmd.command.trim()
                    if (t.startsWith("/")) sendCommand(t.substring(1)) else sendMessage(t)
                } catch (e: Exception) { /* ignore */ }
            }, base + cmd.delaySec.coerceAtLeast(0) * 1000L, TimeUnit.MILLISECONDS)
        }
    }

    // ---------------------------------------------------------------- resource packs

    private fun onPackOffer(r: PacketReader, inConfig: Boolean, server: ServerEntry) {
        val id = r.uuid()
        val url = r.string()
        val hash = r.string()
        val forced = r.bool()
        val prompt = if (r.bool()) ChatParser.plain(r.nbt()) else ""
        val offer = PackOffer(id, url, hash, forced, prompt, inConfig)
        when (server.packMode) {
            PackMode.ACCEPT -> startPackDownload(offer)
            PackMode.DECLINE -> respondPack(offer, 1)
            else -> setState { it.copy(pendingPack = offer) }
        }
    }

    private fun respondPack(offer: PackOffer, result: Int) {
        try {
            val body = PacketWriter().uuid(offer.id).varInt(result).toByteArray()
            conn?.send(if (offer.inConfig) 0x05 else SB_PACK_RESPONSE, body)
        } catch (e: Exception) { /* ignore */ }
    }

    private fun startPackDownload(offer: PackOffer) {
        val t = Thread({
            respondPack(offer, 3) // accepted
            val res = Packs.fetch(ctx, offer.url, offer.hash)
            if (res.ok) {
                Packs.active = res.file
                respondPack(offer, 4) // downloaded
                respondPack(offer, 0) // successfully loaded
                addSystem(if (res.cached) "ریسورس‌پک از حافظه بارگذاری شد" else "ریسورس‌پک دانلود شد", McColors.GREEN)
            } else {
                respondPack(offer, 2) // failed download
                addSystem("دانلود ریسورس‌پک ناموفق بود: ${res.error}", McColors.RED)
            }
        }, "mc-pack")
        t.isDaemon = true
        t.start()
    }
}
