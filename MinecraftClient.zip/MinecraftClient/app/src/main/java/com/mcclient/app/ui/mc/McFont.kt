package com.mcclient.app.ui.mc

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.util.LruCache
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import com.mcclient.app.Core
import java.io.File
import kotlin.math.ceil
import kotlin.math.max

/**
 * Font backend.
 *  - Latin text uses Minecraft's own bitmap font (ascii.png from the official client jar).
 *  - Persian/Arabic-script text (and any other non-ASCII glyph) is rendered through a pixelated pipeline:
 *    drawn without anti-aliasing at a small size and scaled up with nearest-neighbour filtering.
 *    A pixel-style Persian TTF can be imported in Settings; otherwise the system font is used.
 */
object McFont {
    const val LINE_H = 12
    const val BASE = 9

    var version by mutableIntStateOf(0)
        private set

    private var ascii: Bitmap? = null
    private var cell = 8
    private val adv = IntArray(256) { 4 }
    private val has = BooleanArray(256)
    private var persian: Typeface = Typeface.DEFAULT
    private var persianPx = 10f
    private val cache = LruCache<String, PixelRun>(400)

    class PixelRun(val bmp: Bitmap, val asc: Int) {
        val w: Int get() = bmp.width
    }

    val bitmapReady: Boolean get() = ascii != null
    val asciiBitmap: Bitmap? get() = ascii
    val cellSize: Int get() = cell

    fun reload(ctx: Context) {
        persianPx = Core.prefs.persianPx.toFloat()
        var b: Bitmap? = null
        val f = Assets.asciiFile(ctx)
        if (f.exists()) {
            try {
                val o = BitmapFactory.Options()
                o.inScaled = false
                b = BitmapFactory.decodeFile(f.path, o)
            } catch (e: Exception) { b = null }
        }
        ascii = b
        java.util.Arrays.fill(adv, 4)
        java.util.Arrays.fill(has, false)
        if (b != null) {
            cell = max(1, b.width / 16)
            val scale = cell / 8f
            for (ch in 0 until 256) {
                val cx = (ch % 16) * cell
                val cy = (ch / 16) * cell
                if (cx + cell > b.width || cy + cell > b.height) continue
                var w = 0
                var col = cell - 1
                while (col >= 0 && w == 0) {
                    for (row in 0 until cell) {
                        if ((b.getPixel(cx + col, cy + row) ushr 24) != 0) { w = col + 1; break }
                    }
                    col--
                }
                if (w > 0) {
                    has[ch] = true
                    adv[ch] = Math.round(w / scale) + 1
                }
            }
        }
        val tf = File(ctx.filesDir, "fonts/persian.ttf")
        persian = Typeface.DEFAULT
        if (tf.exists()) {
            try { persian = Typeface.createFromFile(tf) } catch (e: Exception) { persian = Typeface.DEFAULT }
        }
        cache.evictAll()
        version++
    }

    fun hasGlyph(code: Int): Boolean = code in 0x21..0x7E && has[code]

    fun charAdv(code: Int): Int = if (code in 0..255) adv[code] else 4

    fun measureLatin(text: String, bold: Boolean): Int {
        if (ascii == null) return pixelRun(text, bold, true).w
        var w = 0
        for (ch in text) w += charAdv(ch.code) + (if (bold) 1 else 0)
        return w
    }

    fun pixelRun(text: String, bold: Boolean, mono: Boolean): PixelRun {
        val key = (if (bold) "b" else "n") + (if (mono) "m" else "p") + text
        val hit = cache.get(key)
        if (hit != null) return hit
        val p = Paint()
        p.isAntiAlias = false
        p.isSubpixelText = false
        p.color = Color.WHITE
        p.textSize = persianPx
        p.typeface = if (mono) Typeface.MONOSPACE else persian
        p.isFakeBoldText = bold
        val fm = p.fontMetrics
        val asc = ceil(-fm.ascent.toDouble()).toInt()
        val h = asc + ceil(fm.descent.toDouble()).toInt() + 1
        val w = ceil(p.measureText(text).toDouble()).toInt() + 1
        val bmp = Bitmap.createBitmap(max(w, 1), max(h, 1), Bitmap.Config.ARGB_8888)
        Canvas(bmp).drawText(text, 0f, asc.toFloat(), p)
        val run = PixelRun(bmp, asc)
        cache.put(key, run)
        return run
    }
}
