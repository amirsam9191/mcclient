package com.mcclient.app.ui

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import com.mcclient.app.Core
import com.mcclient.app.data.PackMode
import com.mcclient.app.data.ServerEntry
import com.mcclient.app.data.StartupCommand
import com.mcclient.app.net.PingResult
import com.mcclient.app.service.ConnectionService
import com.mcclient.app.ui.mc.Assets
import com.mcclient.app.ui.mc.McFont
import com.mcclient.app.ui.mc.McText
import java.util.UUID

private val NAME_RE = Regex("^[A-Za-z0-9_]{1,16}\$")

fun startConnect(ctx: Context, entry: ServerEntry, username: String) {
    // The session must exist before the service starts, otherwise the service would see "idle" and stop itself.
    Core.session.connect(entry, username)
    ConnectionService.start(ctx)
}

@Composable
private fun ltrStyle() = LocalTextStyle.current.copy(textDirection = TextDirection.Ltr)

@Composable
fun HomeScreen(onSettings: () -> Unit, onEdit: (String?) -> Unit) {
    if (Core.prefs.serverListMode) ServerListScreen(onSettings, onEdit) else QuickConnectScreen(onSettings)
}

@Composable
fun AssetBanner() {
    val ctx = LocalContext.current
    val ready = remember(McFont.version) { Assets.has(ctx) }
    if (ready) return
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("فونت اصلی ماینکرافت", fontWeight = FontWeight.Bold)
            Text(
                Assets.status.ifEmpty { "فونت و تکسچرها هنوز از Mojang دانلود نشده‌اند. تا آن زمان از یک فونت جایگزین استفاده می‌شود." },
                style = MaterialTheme.typography.bodySmall
            )
            if (Assets.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            else Button(onClick = {
                val app = ctx.applicationContext
                Thread { Assets.download(app) }.start()
            }) { Text("دانلود فونت و تکسچرها") }
        }
    }
}

@Composable
fun QuickConnectScreen(onSettings: () -> Unit) {
    val ctx = LocalContext.current
    var address by remember { mutableStateOf(Core.prefs.lastAddress) }
    var name by remember { mutableStateOf(Core.prefs.username) }
    var error by remember { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .imePadding()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, contentDescription = "تنظیمات") }
        }
        Spacer(Modifier.height(24.dp))
        Text("ماینکرافت کلاینت", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        Text("کلاینت چت برای سرورهای ماینکرافت جاوا ۱٫۲۰٫۴", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = address,
            onValueChange = { address = it; error = "" },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("آی‌پی سرور (پورت اختیاری)") },
            placeholder = { Text("play.example.com:25565") },
            textStyle = ltrStyle()
        )
        OutlinedTextField(
            value = name,
            onValueChange = { name = it; error = "" },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("نام کاربری") },
            textStyle = ltrStyle()
        )
        if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
        Button(
            onClick = {
                val a = address.trim()
                val n = name.trim()
                if (a.isEmpty()) { error = "آدرس سرور را وارد کنید"; return@Button }
                if (!NAME_RE.matches(n)) { error = "نام کاربری باید ۱ تا ۱۶ حرف انگلیسی، عدد یا _ باشد"; return@Button }
                Core.prefs.setLastAddress(a)
                Core.prefs.setUsername(n)
                startConnect(ctx, ServerEntry(id = "quick", name = a, address = a), n)
            },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("اتصال به سرور") }

        if (Core.lastEnd.isNotEmpty()) {
            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) { Text("آخرین اتصال: ${Core.lastEnd}", Modifier.padding(14.dp), color = MaterialTheme.colorScheme.error) }
        }
        AssetBanner()
    }
}

@Composable
fun ServerListScreen(onSettings: () -> Unit, onEdit: (String?) -> Unit) {
    val ctx = LocalContext.current
    val servers = Core.servers.list
    var toDelete by remember { mutableStateOf<ServerEntry?>(null) }

    LaunchedEffect(servers.size) { servers.toList().forEach { Core.refreshPing(it) } }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("لیست سرورها", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            IconButton(onClick = { servers.toList().forEach { Core.refreshPing(it) } }) { Icon(Icons.Default.Refresh, contentDescription = "رفرش همه") }
            IconButton(onClick = { onEdit(null) }) { Icon(Icons.Default.Add, contentDescription = "افزودن سرور") }
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, contentDescription = "تنظیمات") }
        }
        if (Core.lastEnd.isNotEmpty()) {
            Text("آخرین اتصال: ${Core.lastEnd}", Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
        if (servers.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("هنوز سروری اضافه نکرده‌اید. با دکمهٔ + یک سرور اضافه کنید.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(servers, key = { it.id }) { s ->
                    ServerCard(
                        s,
                        onConnect = {
                            val n = s.username.ifBlank { Core.prefs.username }
                            if (!NAME_RE.matches(n)) onEdit(s.id) else startConnect(ctx, s, n)
                        },
                        onEdit = { onEdit(s.id) },
                        onRefresh = { Core.refreshPing(s) },
                        onDelete = { toDelete = s }
                    )
                }
            }
            AssetBanner()
        }
    }

    val del = toDelete
    if (del != null) {
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("حذف سرور") },
            text = { Text("سرور «${del.name.ifBlank { del.address }}» حذف شود؟") },
            confirmButton = { TextButton(onClick = { Core.servers.delete(del.id); toDelete = null }) { Text("حذف") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("انصراف") } }
        )
    }
}

@Composable
private fun ServerCard(s: ServerEntry, onConnect: () -> Unit, onEdit: () -> Unit, onRefresh: () -> Unit, onDelete: () -> Unit) {
    val ping = Core.pings[s.id]
    val loading = Core.pinging[s.id] == true
    Card(
        Modifier.fillMaxWidth().clickable { onConnect() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                val icon = ping?.icon
                if (icon != null) {
                    Image(icon.asImageBitmap(), contentDescription = null, modifier = Modifier.size(56.dp), filterQuality = FilterQuality.None)
                } else {
                    Box(Modifier.size(56.dp).background(Color(0xFF5B8731)))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.name.ifBlank { s.address }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(s.address, style = ltrStyle().copy(color = MaterialTheme.colorScheme.onSurfaceVariant), maxLines = 1)
                    val p = ping
                    if (p != null && p.ok) {
                        Text("${p.online}/${p.max} بازیکن · ${p.version}", style = MaterialTheme.typography.bodySmall, maxLines = 1)
                    } else if (p != null) {
                        Text("در دسترس نیست", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    } else {
                        Text("در حال بررسی…", style = MaterialTheme.typography.bodySmall)
                    }
                }
                PingBars(ping, loading)
            }
            if (ping != null && ping.ok && ping.motd.isNotEmpty()) {
                Box(Modifier.fillMaxWidth().background(Color(0xCC000000)).padding(4.dp)) { McText(ping.motd) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, contentDescription = "رفرش") }
                IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, contentDescription = "ویرایش") }
                IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "حذف") }
            }
        }
    }
}

@Composable
private fun PingBars(ping: PingResult?, loading: Boolean) {
    val ms = if (ping != null && ping.ok) ping.pingMs else -1L
    val level = if (ms < 0) 0 else if (ms < 100) 5 else if (ms < 200) 4 else if (ms < 350) 3 else if (ms < 600) 2 else 1
    val col = if (level >= 4) Color(0xFF55FF55) else if (level >= 2) Color(0xFFFFAA00) else if (level == 1) Color(0xFFFF5555) else Color(0xFF666666)
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
            for (i in 1..5) {
                Box(Modifier.width(5.dp).height((4 + i * 3).dp).background(if (i <= level) col else Color(0xFF3A3F3C)))
            }
        }
        Text(
            if (loading && ping == null) "…" else if (ms >= 0) "${ms}ms" else "—",
            style = MaterialTheme.typography.labelSmall
        )
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServerEditScreen(id: String?, onDone: () -> Unit) {
    val existing = remember(id) { if (id == null) null else Core.servers.find(id) }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var address by remember { mutableStateOf(existing?.address ?: "") }
    var username by remember { mutableStateOf(existing?.username ?: "") }
    var autoLogin by remember { mutableStateOf(existing?.autoLogin ?: false) }
    var password by remember { mutableStateOf(existing?.password ?: "") }
    var autoRejoin by remember { mutableStateOf(existing?.autoRejoin ?: false) }
    var packMode by remember { mutableStateOf(existing?.packMode ?: PackMode.ASK) }
    val cmds = remember {
        val l = mutableStateListOf<StartupCommand>()
        if (existing != null) l.addAll(existing.commands)
        l
    }
    var error by remember { mutableStateOf("") }

    fun save() {
        val addr = address.trim()
        val u = username.trim()
        if (addr.isEmpty()) { error = "آدرس سرور را وارد کنید"; return }
        if (u.isNotEmpty() && !NAME_RE.matches(u)) { error = "نام کاربری نامعتبر است"; return }
        val entry = ServerEntry(
            id = existing?.id ?: UUID.randomUUID().toString(),
            name = name.trim().ifEmpty { addr },
            address = addr,
            username = u,
            autoLogin = autoLogin,
            password = password,
            autoRejoin = autoRejoin,
            packMode = packMode,
            commands = cmds.filter { it.command.isNotBlank() }
        )
        Core.servers.upsert(entry)
        Core.pings.remove(entry.id)
        onDone()
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .imePadding()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onDone) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت") }
            Text(if (existing == null) "افزودن سرور" else "ویرایش سرور", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("نام سرور") })
        OutlinedTextField(address, { address = it; error = "" }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("آی‌پی سرور (پورت اختیاری)") }, textStyle = ltrStyle())
        OutlinedTextField(
            username, { username = it; error = "" }, Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("نام کاربری (خالی = نام کاربری پیش‌فرض تنظیمات)") }, textStyle = ltrStyle()
        )

        HorizontalDivider()
        SwitchRow("لاگین خودکار (ارسال /login)", autoLogin) { autoLogin = it }
        if (autoLogin) {
            OutlinedTextField(
                password, { password = it }, Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("رمز عبور") }, visualTransformation = PasswordVisualTransformation(), textStyle = ltrStyle()
            )
        }
        SwitchRow("ری‌جوین خودکار (۵ ثانیه پس از کیک شدن)", autoRejoin) { autoRejoin = it }

        HorizontalDivider()
        Text("ریسورس‌پک سرور", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(packMode == PackMode.ASK, { packMode = PackMode.ASK }, label = { Text("بپرس") })
            FilterChip(packMode == PackMode.ACCEPT, { packMode = PackMode.ACCEPT }, label = { Text("همیشه قبول") })
            FilterChip(packMode == PackMode.DECLINE, { packMode = PackMode.DECLINE }, label = { Text("رد کن") })
        }

        HorizontalDivider()
        Text("دستورات پس از ورود", fontWeight = FontWeight.Bold)
        Text(
            "هر دستور بعد از تأخیر مشخص (ثانیه) از ورود به سرور ارسال می‌شود. اگر لاگین خودکار روشن باشد، تأخیر از بعد از لاگین حساب می‌شود. با / شروع شود دستور است، وگرنه پیام چت.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        cmds.forEachIndexed { i, c ->
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    c.command, { v -> cmds[i] = c.copy(command = v) }, Modifier.weight(1f), singleLine = true,
                    label = { Text("دستور یا پیام") }, textStyle = ltrStyle()
                )
                OutlinedTextField(
                    c.delaySec.toString(),
                    { v -> cmds[i] = c.copy(delaySec = v.filter { ch -> ch.isDigit() }.take(4).toIntOrNull() ?: 0) },
                    Modifier.width(88.dp), singleLine = true,
                    label = { Text("ثانیه") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                IconButton(onClick = { cmds.removeAt(i) }) { Icon(Icons.Default.Delete, contentDescription = "حذف") }
            }
        }
        OutlinedButton(onClick = { cmds.add(StartupCommand("", 5)) }) { Text("افزودن دستور") }

        if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { save() }, modifier = Modifier.weight(1f)) { Text("ذخیره") }
            OutlinedButton(onClick = onDone, modifier = Modifier.weight(1f)) { Text("انصراف") }
        }
    }
}
