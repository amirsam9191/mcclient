package com.mcclient.app.ui

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.mcclient.app.Core
import com.mcclient.app.game.ChatLine
import com.mcclient.app.game.Status
import com.mcclient.app.ui.mc.McText
import kotlinx.coroutines.delay

@Composable
fun ChatScreen() {
    val ctx = LocalContext.current
    val session = Core.session
    val st by session.state.collectAsState()
    val lines by session.chat.collectAsState()
    val clipboard = LocalClipboardManager.current
    val listState = rememberLazyListState()
    var tf by remember { mutableStateOf(TextFieldValue("")) }
    var histIdx by remember { mutableIntStateOf(-1) }

    BackHandler { (ctx as? Activity)?.moveTaskToBack(true) }

    LaunchedEffect(lines.size) {
        if (lines.isNotEmpty()) {
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1
            if (last < 0 || last >= lines.size - 3) listState.scrollToItem(lines.size - 1)
        }
    }
    LaunchedEffect(tf.text) {
        val t = tf.text
        delay(150)
        session.requestSuggestions(t)
    }

    fun send() {
        val t = tf.text
        if (t.isBlank()) return
        if (session.sendUserText(t)) {
            Core.prefs.addHistory(t)
            tf = TextFieldValue("")
            histIdx = -1
            session.clearSuggestions()
        }
    }

    fun setText(s: String) { tf = TextFieldValue(s, TextRange(s.length)) }

    fun prev() {
        val h = Core.prefs.history()
        if (h.isEmpty()) return
        histIdx = if (histIdx == -1) h.size - 1 else maxOf(0, histIdx - 1)
        setText(h[histIdx])
    }

    fun next() {
        val h = Core.prefs.history()
        if (histIdx == -1) return
        histIdx++
        if (histIdx >= h.size) { histIdx = -1; setText("") } else setText(h[histIdx])
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .imePadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(st.serverName, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                Text(
                    when (st.status) {
                        Status.ONLINE -> "متصل · ${st.players.size} بازیکن آنلاین"
                        Status.CONNECTING -> st.info
                        Status.WAITING_RECONNECT -> "قطع شد"
                        Status.IDLE -> ""
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
            TextButton(onClick = { clipboard.setText(AnnotatedString(lines.joinToString("\n") { it.plain })) }) {
                Text("کپی همه")
            }
            Button(
                onClick = { session.disconnect() },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error, contentColor = Color.White)
            ) { Text("قطع اتصال") }
        }

        if (st.status == Status.WAITING_RECONNECT) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF5A3B00))
                    .padding(8.dp)
            ) {
                Text("اتصال مجدد تا ${st.reconnectIn} ثانیه دیگر… (برای توقف، قطع اتصال را بزنید)", color = Color.White)
            }
        }

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize().padding(horizontal = 4.dp),
                verticalArrangement = Arrangement.spacedBy(1.dp)
            ) {
                items(lines, key = { it.id }) { line -> ChatRow(line, clipboard) }
            }
            if (st.actionBar.isNotEmpty()) {
                var visible by remember(st.actionBarNonce) { mutableStateOf(true) }
                LaunchedEffect(st.actionBarNonce) { delay(3000); visible = false }
                if (visible) {
                    Box(
                        Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 6.dp)
                            .background(Color(0xAA000000))
                            .widthIn(max = 320.dp)
                    ) { McText(st.actionBar) }
                }
            }
        }

        if (st.status == Status.ONLINE) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Hearts(st.health)
                    Hunger(st.food)
                }
            }
            if (st.health <= 0f) {
                Button(onClick = { session.respawn() }, modifier = Modifier.padding(horizontal = 8.dp)) { Text("ریسپاون") }
            }
        }

        val sug = st.suggestions
        if (sug != null && sug.items.isNotEmpty()) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(sug.items) { item ->
                    AssistChip(
                        onClick = {
                            val text = tf.text
                            val s = sug.start.coerceIn(0, text.length)
                            val e = (sug.start + sug.length).coerceIn(s, text.length)
                            val nt = text.substring(0, s) + item + text.substring(e)
                            tf = TextFieldValue(nt, TextRange(s + item.length))
                            session.clearSuggestions()
                        },
                        label = { Text(item, maxLines = 1) }
                    )
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { prev() }) { Icon(Icons.Default.KeyboardArrowUp, contentDescription = "پیام قبلی") }
            IconButton(onClick = { next() }) { Icon(Icons.Default.KeyboardArrowDown, contentDescription = "پیام بعدی") }
            OutlinedTextField(
                value = tf,
                onValueChange = { tf = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("پیام یا دستور (با /)") },
                textStyle = LocalTextStyle.current.copy(textDirection = TextDirection.Content),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send() })
            )
            IconButton(onClick = { send() }) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "ارسال") }
        }
    }

    val offer = st.pendingPack
    if (offer != null) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("ریسورس‌پک سرور") },
            text = {
                Text(
                    "سرور یک ریسورس‌پک پیشنهاد می‌دهد" + (if (offer.forced) " (اجباری)" else "") +
                        (if (offer.prompt.isNotBlank()) "\n" + offer.prompt else "") +
                        "\n\nدانلود شود؟ اگر پک قبلاً دانلود شده و تغییری نکرده باشد، دوباره دانلود نمی‌شود."
                )
            },
            confirmButton = { TextButton(onClick = { session.answerPack(true) }) { Text("بله، دانلود کن") } },
            dismissButton = { TextButton(onClick = { session.answerPack(false) }) { Text("خیر") } }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChatRow(line: ChatLine, clipboard: ClipboardManager) {
    var menu by remember { mutableStateOf(false) }
    Box(
        Modifier
            .fillMaxWidth()
            .background(Color(0x66000000))
            .combinedClickable(onClick = {}, onLongClick = { menu = true })
            .padding(horizontal = 4.dp)
    ) {
        McText(line.spans)
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(
                text = { Text("کپی پیام") },
                onClick = { clipboard.setText(AnnotatedString(line.plain)); menu = false }
            )
        }
    }
}
