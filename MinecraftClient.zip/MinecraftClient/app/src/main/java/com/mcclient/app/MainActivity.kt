package com.mcclient.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.mcclient.app.game.Status
import com.mcclient.app.ui.ChatScreen
import com.mcclient.app.ui.HomeScreen
import com.mcclient.app.ui.McTheme
import com.mcclient.app.ui.ServerEditScreen
import com.mcclient.app.ui.SettingsScreen
import com.mcclient.app.ui.mc.Assets
import com.mcclient.app.ui.requestIgnoreBattery

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            McTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { AppRoot() }
            }
        }
    }
}

private sealed interface Route {
    object Home : Route
    object Settings : Route
    class Edit(val id: String?) : Route
}

@Composable
private fun AppRoot() {
    val ctx = LocalContext.current
    val st by Core.session.state.collectAsState()
    var route by remember { mutableStateOf<Route>(Route.Home) }
    var showOnboarding by remember { mutableStateOf(!Core.prefs.onboardingDone) }

    // First launch: fetch Minecraft's font/textures from Mojang once.
    LaunchedEffect(Unit) {
        if (!Assets.autoStarted && !Assets.has(ctx)) {
            Assets.autoStarted = true
            val app = ctx.applicationContext
            Thread { Assets.download(app) }.start()
        }
    }

    val inGame = st.status != Status.IDLE
    BackHandler(enabled = !inGame && route != Route.Home) { route = Route.Home }

    if (inGame) {
        ChatScreen()
    } else {
        when (val r = route) {
            is Route.Home -> HomeScreen(onSettings = { route = Route.Settings }, onEdit = { route = Route.Edit(it) })
            is Route.Settings -> SettingsScreen(onBack = { route = Route.Home })
            is Route.Edit -> ServerEditScreen(r.id, onDone = { route = Route.Home })
        }
    }

    if (showOnboarding) {
        val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
            requestIgnoreBattery(ctx)
        }
        AlertDialog(
            onDismissRequest = {},
            title = { Text("مجوزهای لازم") },
            text = {
                Text(
                    "برای اینکه اتصال به سرور حتی با بسته شدن برنامه یا خاموش شدن صفحه باقی بماند، " +
                        "برنامه به مجوز نوتیفیکیشن (برای سرویس پس‌زمینه) و اجازهٔ نادیده گرفتن بهینه‌سازی باتری نیاز دارد."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showOnboarding = false
                    Core.prefs.setOnboardingDone()
                    if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
                    else requestIgnoreBattery(ctx)
                }) { Text("ادامه") }
            }
        )
    }
}
