package com.mcclient.app.data

import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object PackMode {
    const val ASK = 0
    const val ACCEPT = 1
    const val DECLINE = 2
}

/** A command that is sent automatically [delaySec] seconds after joining (after auto-login if enabled). */
data class StartupCommand(val command: String, val delaySec: Int)

data class ServerEntry(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    val address: String = "",
    val username: String = "",
    val autoLogin: Boolean = false,
    val password: String = "",
    val autoRejoin: Boolean = false,
    val packMode: Int = PackMode.ASK,
    val commands: List<StartupCommand> = emptyList()
)

fun ServerEntry.toJson(): JSONObject {
    val cmds = JSONArray()
    for (c in commands) cmds.put(JSONObject().put("c", c.command).put("d", c.delaySec))
    return JSONObject()
        .put("id", id).put("name", name).put("address", address).put("username", username)
        .put("autoLogin", autoLogin).put("password", password).put("autoRejoin", autoRejoin)
        .put("packMode", packMode).put("commands", cmds)
}

fun serverFromJson(o: JSONObject): ServerEntry {
    val list = ArrayList<StartupCommand>()
    val arr = o.optJSONArray("commands")
    if (arr != null) for (i in 0 until arr.length()) {
        val c = arr.getJSONObject(i)
        list.add(StartupCommand(c.optString("c", ""), c.optInt("d", 0)))
    }
    return ServerEntry(
        id = o.optString("id", UUID.randomUUID().toString()),
        name = o.optString("name", ""),
        address = o.optString("address", ""),
        username = o.optString("username", ""),
        autoLogin = o.optBoolean("autoLogin", false),
        password = o.optString("password", ""),
        autoRejoin = o.optBoolean("autoRejoin", false),
        packMode = o.optInt("packMode", PackMode.ASK),
        commands = list
    )
}

class ServerStore(private val sp: SharedPreferences) {
    val list = mutableStateListOf<ServerEntry>()

    init {
        try {
            val a = JSONArray(sp.getString("servers", "[]"))
            for (i in 0 until a.length()) list.add(serverFromJson(a.getJSONObject(i)))
        } catch (e: Exception) { /* start empty */ }
    }

    private fun save() {
        val a = JSONArray()
        for (s in list) a.put(s.toJson())
        sp.edit().putString("servers", a.toString()).apply()
    }

    fun upsert(s: ServerEntry) {
        val i = list.indexOfFirst { it.id == s.id }
        if (i >= 0) list[i] = s else list.add(s)
        save()
    }

    fun delete(id: String) {
        list.removeAll { it.id == id }
        save()
    }

    fun find(id: String): ServerEntry? = list.firstOrNull { it.id == id }
}

class Prefs(private val sp: SharedPreferences) {
    var serverListMode by mutableStateOf(sp.getBoolean("server_list_mode", false)); private set
    var username by mutableStateOf(sp.getString("username", "") ?: ""); private set
    var lastAddress by mutableStateOf(sp.getString("last_address", "") ?: ""); private set
    var autoRespawn by mutableStateOf(sp.getBoolean("auto_respawn", true)); private set
    var chatScale by mutableFloatStateOf(sp.getFloat("chat_scale", 1f)); private set
    var persianPx by mutableIntStateOf(sp.getInt("persian_px", 10)); private set
    var onboardingDone by mutableStateOf(sp.getBoolean("onboarding_done", false)); private set

    fun setServerListMode(v: Boolean) { serverListMode = v; sp.edit().putBoolean("server_list_mode", v).apply() }
    fun setUsername(v: String) { username = v; sp.edit().putString("username", v).apply() }
    fun setLastAddress(v: String) { lastAddress = v; sp.edit().putString("last_address", v).apply() }
    fun setAutoRespawn(v: Boolean) { autoRespawn = v; sp.edit().putBoolean("auto_respawn", v).apply() }
    fun setChatScale(v: Float) { chatScale = v; sp.edit().putFloat("chat_scale", v).apply() }
    fun setPersianPx(v: Int) { persianPx = v; sp.edit().putInt("persian_px", v).apply() }
    fun setOnboardingDone() { onboardingDone = true; sp.edit().putBoolean("onboarding_done", true).apply() }

    // Sent-message history (used by the previous/next message buttons).
    private val hist = ArrayList<String>()

    init {
        try {
            val a = JSONArray(sp.getString("history", "[]"))
            for (i in 0 until a.length()) hist.add(a.getString(i))
        } catch (e: Exception) { /* empty */ }
    }

    fun history(): List<String> = ArrayList(hist)

    fun addHistory(s: String) {
        if (s.isBlank()) return
        if (hist.isNotEmpty() && hist.last() == s) return
        hist.add(s)
        while (hist.size > 100) hist.removeAt(0)
        val a = JSONArray()
        for (h in hist) a.put(h)
        sp.edit().putString("history", a.toString()).apply()
    }
}
