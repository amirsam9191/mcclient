package com.mcclient.app.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.mcclient.app.Core
import com.mcclient.app.MainActivity
import com.mcclient.app.R
import com.mcclient.app.game.SessionState
import com.mcclient.app.game.Status
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Keeps the process alive (foreground service + wake/wifi locks) while a Minecraft session is open. */
class ConnectionService : Service() {
    companion object {
        const val CHANNEL = "mc_connection"
        const val NOTIF_ID = 1
        const val ACTION_STOP = "com.mcclient.app.STOP"

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, ConnectionService::class.java))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    @SuppressLint("WakelockTimeout")
    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "اتصال به سرور", NotificationManager.IMPORTANCE_LOW))
        }
        val n = build("در حال اتصال…")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mcclient:connection").also {
                it.setReferenceCounted(false); it.acquire()
            }
            @Suppress("DEPRECATION")
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "mcclient:wifi").also {
                it.setReferenceCounted(false); it.acquire()
            }
        } catch (e: Exception) { /* locks are best-effort */ }

        scope.launch {
            Core.session.state.collect { st ->
                if (st.status == Status.IDLE) {
                    stopSelf()
                } else {
                    nm.notify(NOTIF_ID, build(textFor(st)))
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Core.session.disconnect()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        try { wake?.let { if (it.isHeld) it.release() } } catch (e: Exception) { /* ignore */ }
        try { wifi?.let { if (it.isHeld) it.release() } } catch (e: Exception) { /* ignore */ }
        super.onDestroy()
    }

    private fun textFor(st: SessionState): String = when (st.status) {
        Status.ONLINE -> "متصل به ${st.serverName}"
        Status.WAITING_RECONNECT -> "اتصال مجدد تا ${st.reconnectIn} ثانیه دیگر…"
        else -> "در حال اتصال به ${st.serverName}…"
    }

    private fun build(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, ConnectionService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("ماینکرافت کلاینت")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(0, "قطع اتصال", stop)
            .build()
    }
}
