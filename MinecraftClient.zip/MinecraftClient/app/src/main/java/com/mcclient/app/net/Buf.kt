package com.mcclient.app.net

import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.UUID

/** Thrown when a packet body cannot be parsed. The session ignores such packets. */
class ParseException(msg: String) : RuntimeException(msg)

class PacketWriter {
    private val out = ByteArrayOutputStream()

    fun byte(v: Int): PacketWriter { out.write(v and 0xFF); return this }
    fun bool(v: Boolean): PacketWriter = byte(if (v) 1 else 0)
    fun short(v: Int): PacketWriter { out.write((v shr 8) and 0xFF); out.write(v and 0xFF); return this }
    fun int(v: Int): PacketWriter {
        out.write((v shr 24) and 0xFF); out.write((v shr 16) and 0xFF)
        out.write((v shr 8) and 0xFF); out.write(v and 0xFF)
        return this
    }
    fun long(v: Long): PacketWriter {
        var s = 56
        while (s >= 0) { out.write(((v shr s) and 0xFF).toInt()); s -= 8 }
        return this
    }
    fun float(v: Float): PacketWriter = int(java.lang.Float.floatToIntBits(v))
    fun double(v: Double): PacketWriter = long(java.lang.Double.doubleToLongBits(v))
    fun varInt(value: Int): PacketWriter {
        var v = value
        while (true) {
            if ((v and 0x7F.inv()) == 0) { out.write(v); return this }
            out.write((v and 0x7F) or 0x80)
            v = v ushr 7
        }
    }
    fun string(s: String): PacketWriter {
        val b = s.toByteArray(Charsets.UTF_8)
        varInt(b.size); out.write(b)
        return this
    }
    fun uuid(u: UUID): PacketWriter = long(u.mostSignificantBits).long(u.leastSignificantBits)
    fun bytes(b: ByteArray): PacketWriter { out.write(b); return this }
    fun toByteArray(): ByteArray = out.toByteArray()
}

class PacketReader(private val buf: ByteArray, var pos: Int = 0, private val end: Int = buf.size) {
    fun remaining(): Int = end - pos

    fun ubyte(): Int {
        if (pos >= end) throw ParseException("eof")
        return buf[pos++].toInt() and 0xFF
    }
    fun byte(): Int = ubyte().toByte().toInt()
    fun bool(): Boolean = ubyte() != 0
    /** Unsigned 16-bit value. */
    fun short(): Int = (ubyte() shl 8) or ubyte()
    fun int(): Int = (ubyte() shl 24) or (ubyte() shl 16) or (ubyte() shl 8) or ubyte()
    fun long(): Long { val hi = int().toLong(); val lo = int().toLong() and 0xFFFFFFFFL; return (hi shl 32) or lo }
    fun float(): Float = java.lang.Float.intBitsToFloat(int())
    fun double(): Double = java.lang.Double.longBitsToDouble(long())
    fun varInt(): Int {
        var r = 0
        var shift = 0
        while (true) {
            val b = ubyte()
            r = r or ((b and 0x7F) shl shift)
            if ((b and 0x80) == 0) return r
            shift += 7
            if (shift > 35) throw ParseException("varint too long")
        }
    }
    fun skip(n: Int) {
        if (n < 0 || pos + n > end) throw ParseException("skip out of range")
        pos += n
    }
    fun bytes(n: Int): ByteArray {
        if (n < 0 || pos + n > end) throw ParseException("bytes out of range")
        val r = buf.copyOfRange(pos, pos + n); pos += n; return r
    }
    fun string(): String {
        val n = varInt()
        if (n < 0 || pos + n > end) throw ParseException("string out of range")
        val s = String(buf, pos, n, Charsets.UTF_8); pos += n; return s
    }
    fun uuid(): UUID { val a = long(); val b = long(); return UUID(a, b) }
    fun nbt(): Any? = Nbt.readNetwork(this)
}

/**
 * Network NBT reader (1.20.2+: root tag has no name).
 * Compound -> Map<String, Any?>, List -> List<Any?>, String -> String, numbers -> boxed Kotlin numbers.
 */
object Nbt {
    fun readNetwork(r: PacketReader): Any? {
        val t = r.ubyte()
        if (t == 0) return null
        return payload(r, t)
    }

    private fun payload(r: PacketReader, t: Int): Any? = when (t) {
        1 -> r.byte().toByte()
        2 -> r.short().toShort()
        3 -> r.int()
        4 -> r.long()
        5 -> r.float()
        6 -> r.double()
        7 -> r.bytes(r.int())
        8 -> str(r)
        9 -> {
            val et = r.ubyte()
            val n = r.int()
            if (n < 0 || n > 1_000_000) throw ParseException("bad nbt list")
            val l = ArrayList<Any?>()
            for (i in 0 until n) l.add(payload(r, et))
            l
        }
        10 -> {
            val m = LinkedHashMap<String, Any?>()
            while (true) {
                val et = r.ubyte()
                if (et == 0) break
                val name = str(r)
                m[name] = payload(r, et)
            }
            m
        }
        11 -> { val n = r.int(); if (n < 0) throw ParseException("bad nbt array"); IntArray(n) { r.int() } }
        12 -> { val n = r.int(); if (n < 0) throw ParseException("bad nbt array"); LongArray(n) { r.long() } }
        else -> throw ParseException("bad nbt tag $t")
    }

    private fun str(r: PacketReader): String {
        val n = r.short()
        return String(r.bytes(n), Charsets.UTF_8)
    }
}

object Json {
    /** Converts org.json values into the same Map/List/String shapes the NBT reader produces. */
    fun toAny(o: Any?): Any? = when (o) {
        null -> null
        JSONObject.NULL -> null
        is JSONObject -> {
            val m = LinkedHashMap<String, Any?>()
            val it = o.keys()
            while (it.hasNext()) { val k = it.next(); m[k] = toAny(o.get(k)) }
            m
        }
        is JSONArray -> {
            val l = ArrayList<Any?>()
            for (i in 0 until o.length()) l.add(toAny(o.get(i)))
            l
        }
        else -> o
    }
}

