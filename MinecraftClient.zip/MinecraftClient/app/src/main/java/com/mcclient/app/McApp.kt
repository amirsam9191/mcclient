package com.mcclient.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.mcclient.app.data.Prefs
import com.mcclient.app.data.ServerEntry
import com.mcclient.app.data.ServerStore
import com.mcclient.app.game.Session
import com.mcclient.app.net.PingResult
import com.mcclient.app.net.ServerPinger
import com.mcclient.app.ui.mc.McFont

object Core {
    lateinit var app: Application
    lateinit var prefs: Prefs
    lateinit var servers: ServerStore
    lateinit var session: Session

    /** Last server-list ping result per server id. */
    val pings = mutableStateMapOf<String, PingResult>()
    val pinging = mutableStateMapOf<String, Boolean>()

    /** Why the previous session ended (shown on the home screen). */
    var lastEnd by mutableStateOf("")

    fun init(a: Application) {
        app = a
        val sp = a.getSharedPreferences("mc_prefs", 0)
        prefs = Prefs(sp)
        servers = ServerStore(sp)
        session = Session(a)
        McFont.reload(a)
    }

    fun refreshPing(s: ServerEntry) {
        if (pinging[s.id] == true) return
        pinging[s.id] = true
        val t = Thread({
            val r = ServerPinger.ping(s.address)
            pings[s.id] = r
            pinging[s.id] = false
        }, "mc-ping")
        t.isDaemon = true
        t.start()
    }
}

class McApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Core.init(this)
    }
}
