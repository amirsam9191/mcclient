package com.mcclient.app.ui.mc

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.Rect
import android.graphics.RectF
import com.mcclient.app.game.ChatSpan
import java.text.Bidi

enum class SegType { AR, LT, NUM, EXT, SPACE }

class Seg(val text: String, val type: SegType, val span: ChatSpan) {
    var width = 0
    var level = 0
    var x = 0
}

class Layout(val lines: List<List<Seg>>, val heightGp: Int)

/**
 * Chat text layout in "game pixels".
 * Words are classified by script: Latin/ASCII (Minecraft bitmap font), Persian/Arabic script (pixel Persian renderer),
 * digits, spaces and other glyphs. Lines are wrapped word by word and reordered with a bidi pass so Persian and English
 * can be mixed in one message without scrambling.
 */
object McLayout {

    private fun isArabic(c: Char): Boolean =
        c in '\u0600'..'\u06FF' || c in '\u0750'..'\u077F' || c in '\u08A0'..'\u08FF' ||
            c in '\uFB50'..'\uFDFF' || c in '\uFE70'..'\uFEFF' || c == '\u200C' || c == '\u200D'

    private fun typeOf(t: String, i: Int): SegType {
        val c = t[i]
        if (c == ' ' || c == '\t' || c == '\u00A0') return SegType.SPACE
        if (isArabic(c)) return SegType.AR
        if (c in '0'..'9') return SegType.NUM
        val prevDigit = i > 0 && t[i - 1] in '0'..'9'
        val nextDigit = i + 1 < t.length && t[i + 1] in '0'..'9'
        if ((c == '.' || c == ',' || c == ':' || c == '/') && prevDigit && nextDigit) return SegType.NUM
        if (c == '%' && prevDigit) return SegType.NUM
        if (c.code in 0x21..0x7E) return SegType.LT
        return SegType.EXT
    }

    private fun isSpaceChar(c: Char) = c == ' ' || c == '\t' || c == '\u00A0'

    private fun tokenize(sp: ChatSpan, out: MutableList<Seg?>) {
        val t = sp.text
        var i = 0
        while (i < t.length) {
            if (t[i] == '\n') { out.add(null); i++; continue }
            val type = typeOf(t, i)
            var j = i + 1
            if (type == SegType.SPACE) {
                while (j < t.length && isSpaceChar(t[j])) j++
            } else {
                while (j < t.length && t[j] != '\n' && typeOf(t, j) == type) j++
            }
            out.add(Seg(t.substring(i, j), type, sp))
            i = j
        }
    }

    private fun measure(s: Seg): Int = when (s.type) {
        SegType.SPACE -> s.text.length * (4 + (if (s.span.bold) 1 else 0))
        SegType.AR, SegType.EXT -> McFont.pixelRun(s.text, s.span.bold, false).w
        SegType.LT, SegType.NUM -> McFont.measureLatin(s.text, s.span.bold)
    }

    private fun mk(text: String, type: SegType, span: ChatSpan): Seg {
        val s = Seg(text, type, span)
        s.width = measure(s)
        return s
    }

    private fun cutIndex(seg: Seg, avail: Int): Int {
        var w = 0
        var n = 0
        val per = if (seg.text.isEmpty()) 1 else seg.width / seg.text.length
        for (ch in seg.text) {
            val cw = if (McFont.bitmapReady) McFont.charAdv(ch.code) + (if (seg.span.bold) 1 else 0) else per
            if (w + cw > avail) break
            w += cw
            n++
        }
        return n
    }

    private fun prevNonSpace(line: List<Seg>, k: Int): Seg? {
        var i = k - 1
        while (i >= 0) { if (line[i].type != SegType.SPACE) return line[i]; i-- }
        return null
    }

    private fun levelLeft(line: List<Seg>, k: Int): Int? {
        var i = k - 1
        while (i >= 0) { if (line[i].type != SegType.SPACE) return line[i].level; i-- }
        return null
    }

    private fun levelRight(line: List<Seg>, k: Int): Int? {
        var i = k + 1
        while (i < line.size) { if (line[i].type != SegType.SPACE) return line[i].level; i++ }
        return null
    }

    fun build(spans: List<ChatSpan>, maxGp: Int): Layout {
        val limit = if (maxGp < 20) 20 else maxGp
        val items = ArrayList<Seg?>()
        for (sp in spans) tokenize(sp, items)
        for (s in items) if (s != null) s.width = measure(s)

        // Base direction of the whole message: first strong character decides.
        var rtl = false
        for (s in items) {
            if (s == null) continue
            if (s.type == SegType.AR) { rtl = true; break }
            if (s.type == SegType.LT && s.text.any { it.isLetter() }) break
        }

        // Word wrapping.
        val lines = ArrayList<MutableList<Seg>>()
        var cur = ArrayList<Seg>()
        var curW = 0
        fun flush() {
            while (cur.isNotEmpty() && cur[cur.size - 1].type == SegType.SPACE) cur.removeAt(cur.size - 1)
            lines.add(cur)
            cur = ArrayList()
            curW = 0
        }
        var i = 0
        while (i < items.size) {
            val s = items[i]
            if (s == null) { flush(); i++; continue }
            if (s.type == SegType.SPACE) {
                if (cur.isNotEmpty()) {
                    if (curW + s.width > limit) flush() else { cur.add(s); curW += s.width }
                }
                i++
                continue
            }
            val word = ArrayList<Seg>()
            var ww = 0
            while (i < items.size) {
                val t = items[i]
                if (t == null || t.type == SegType.SPACE) break
                word.add(t); ww += t.width; i++
            }
            if (curW + ww > limit && cur.isNotEmpty()) flush()
            if (ww <= limit) {
                cur.addAll(word); curW += ww
            } else {
                for (seg in word) {
                    var rest: Seg = seg
                    while (true) {
                        if (curW + rest.width <= limit || rest.type == SegType.AR || rest.type == SegType.EXT) {
                            cur.add(rest); curW += rest.width
                            break
                        }
                        var n = cutIndex(rest, limit - curW)
                        if (n == 0) {
                            if (cur.isNotEmpty()) { flush(); continue }
                            n = 1
                        }
                        val head = mk(rest.text.substring(0, n), rest.type, rest.span)
                        cur.add(head); curW += head.width
                        flush()
                        if (n >= rest.text.length) break
                        rest = mk(rest.text.substring(n), rest.type, rest.span)
                    }
                }
            }
        }
        if (cur.isNotEmpty() || lines.isEmpty()) flush()

        // Bidi levels, visual ordering, x positions.
        val base = if (rtl) 1 else 0
        val ordered = ArrayList<List<Seg>>()
        for (line in lines) {
            val n = line.size
            if (n == 0) { ordered.add(line); continue }
            for (k in 0 until n) {
                val s = line[k]
                s.level = when (s.type) {
                    SegType.AR -> 1
                    SegType.LT, SegType.EXT -> if (base == 1) 2 else 0
                    SegType.NUM -> if (base == 1 || prevNonSpace(line, k)?.type == SegType.AR) 2 else 0
                    SegType.SPACE -> -1
                }
            }
            for (k in 0 until n) {
                if (line[k].level != -1) continue
                val a = levelLeft(line, k)
                val b = levelRight(line, k)
                line[k].level = if (a != null && b != null) {
                    if (a == b) a else if (a >= 1 && b >= 1) 1 else base
                } else base
            }
            val lv = ByteArray(n) { line[it].level.toByte() }
            val idx = arrayOfNulls<Any>(n)
            for (k in 0 until n) idx[k] = k
            Bidi.reorderVisually(lv, 0, idx, 0, n)
            val vis = ArrayList<Seg>(n)
            var total = 0
            for (k in 0 until n) { val s = line[idx[k] as Int]; vis.add(s); total += s.width }
            var x = if (rtl) maxOf(0, limit - total) else 0
            for (s in vis) { s.x = x; x += s.width }
            ordered.add(vis)
        }
        return Layout(ordered, ordered.size * McFont.LINE_H + 2)
    }

    private fun shadowOf(c: Int): Int {
        val r = ((c shr 16) and 0xFF) / 4
        val g = ((c shr 8) and 0xFF) / 4
        val b = (c and 0xFF) / 4
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }

    fun draw(canvas: Canvas, layout: Layout, unit: Int) {
        val paint = Paint()
        paint.isAntiAlias = false
        paint.isFilterBitmap = false
        val src = Rect()
        val dst = RectF()
        val u = unit.toFloat()
        val ascii = McFont.asciiBitmap
        val cell = McFont.cellSize
        for ((li, line) in layout.lines.withIndex()) {
            val top = 1 + li * McFont.LINE_H
            for (s in line) {
                if (s.type == SegType.SPACE && !s.span.underline && !s.span.strike) continue
                for (pass in 0..1) {
                    val shadow = pass == 0
                    val color = if (shadow) shadowOf(s.span.color) else s.span.color
                    val off = if (shadow) 1 else 0
                    paint.colorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
                    canvas.save()
                    if (s.span.italic) {
                        val by = (top + McFont.BASE + off) * u
                        canvas.translate(0f, by)
                        canvas.skew(-0.2f, 0f)
                        canvas.translate(0f, -by)
                    }
                    val usePixel = s.type == SegType.AR || s.type == SegType.EXT || (ascii == null && s.type != SegType.SPACE)
                    if (usePixel) {
                        val run = McFont.pixelRun(s.text, s.span.bold, s.type == SegType.LT || s.type == SegType.NUM)
                        val l = (s.x + off) * u
                        val t = (top + McFont.BASE - run.asc + off) * u
                        dst.set(l, t, l + run.w * u, t + run.bmp.height * u)
                        canvas.drawBitmap(run.bmp, null, dst, paint)
                    } else if (s.type == SegType.LT || s.type == SegType.NUM) {
                        var x = s.x + off
                        for (ch in s.text) {
                            val code = ch.code
                            if (ascii != null && McFont.hasGlyph(code)) {
                                src.set((code % 16) * cell, (code / 16) * cell, (code % 16) * cell + cell, (code / 16) * cell + cell)
                                val gl = x * u
                                val gt = (top + McFont.BASE - 7 + off) * u
                                dst.set(gl, gt, gl + 8 * u, gt + 8 * u)
                                canvas.drawBitmap(ascii, src, dst, paint)
                                if (s.span.bold) {
                                    dst.offset(u, 0f)
                                    canvas.drawBitmap(ascii, src, dst, paint)
                                }
                            }
                            x += McFont.charAdv(code) + (if (s.span.bold) 1 else 0)
                        }
                    }
                    if (s.span.underline) {
                        canvas.drawRect((s.x + off) * u, (top + McFont.BASE + 1 + off) * u, (s.x + s.width + off) * u, (top + McFont.BASE + 2 + off) * u, paint)
                    }
                    if (s.span.strike) {
                        canvas.drawRect((s.x + off) * u, (top + McFont.BASE - 3 + off) * u, (s.x + s.width + off) * u, (top + McFont.BASE - 2 + off) * u, paint)
                    }
                    canvas.restore()
                }
            }
        }
    }
}
