package com.mcclient.app.game

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** Server resource-pack cache. A pack is only downloaded again when its hash changed. */
object Packs {
    @Volatile var active: File? = null

    private fun dir(ctx: Context): File = File(ctx.filesDir, "packs").also { it.mkdirs() }

    private fun hex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }

    private fun sha1OfString(s: String): String = hex(MessageDigest.getInstance("SHA-1").digest(s.toByteArray()))

    fun sha1(f: File): String {
        val md = MessageDigest.getInstance("SHA-1")
        f.inputStream().use { ins ->
            val buf = ByteArray(32768)
            while (true) { val n = ins.read(buf); if (n < 0) break; md.update(buf, 0, n) }
        }
        return hex(md.digest())
    }

    class Result(val ok: Boolean, val cached: Boolean, val file: File?, val error: String = "")

    fun fetch(ctx: Context, url: String, expectedHash: String): Result {
        val target = File(dir(ctx), sha1OfString(url) + ".zip")
        val want = expectedHash.trim().lowercase()
        try {
            if (target.exists() && want.isNotEmpty() && sha1(target) == want) return Result(true, true, target)
            var current = url
            var conn: HttpURLConnection? = null
            for (hop in 0 until 6) {
                val c = URL(current).openConnection() as HttpURLConnection
                c.instanceFollowRedirects = false
                c.connectTimeout = 15000
                c.readTimeout = 30000
                c.setRequestProperty("User-Agent", "MinecraftClientApp/0.1")
                val code = c.responseCode
                if (code in 300..399) {
                    val loc = c.getHeaderField("Location") ?: return Result(false, false, null, "redirect without location")
                    current = URL(URL(current), loc).toString()
                    c.disconnect()
                    continue
                }
                if (code != 200) { c.disconnect(); return Result(false, false, null, "HTTP $code") }
                conn = c
                break
            }
            if (conn == null) return Result(false, false, null, "too many redirects")
            val tmp = File(target.path + ".tmp")
            conn.inputStream.use { ins -> tmp.outputStream().use { outs -> ins.copyTo(outs) } }
            conn.disconnect()
            if (want.isNotEmpty() && sha1(tmp) != want) {
                tmp.delete()
                return Result(false, false, null, "hash mismatch")
            }
            if (target.exists()) target.delete()
            tmp.renameTo(target)
            return Result(true, false, target)
        } catch (e: Exception) {
            return Result(false, false, null, e.message ?: e.javaClass.simpleName)
        }
    }
}
