package com.mcclient.app.ui.mc

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * Minecraft's font and item textures are Mojang's property, so they are not bundled.
 * They are downloaded once from Mojang's official servers (the 1.20.4 client jar) and extracted locally.
 */
object Assets {
    const val VERSION = "1.20.4"
    private const val MANIFEST = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
    private val KEEP_PREFIXES = listOf(
        "assets/minecraft/textures/font/",
        "assets/minecraft/textures/item/",
        "assets/minecraft/textures/gui/sprites/hud/"
    )

    var status by mutableStateOf("")
    var busy by mutableStateOf(false)
    @Volatile var autoStarted = false

    fun dir(ctx: Context): File = File(ctx.filesDir, "mc")
    fun asciiFile(ctx: Context): File = File(dir(ctx), "assets/minecraft/textures/font/ascii.png")
    fun has(ctx: Context): Boolean = asciiFile(ctx).exists()

    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.setRequestProperty("User-Agent", "MinecraftClientApp/0.1")
        return c
    }

    private fun getText(url: String): String {
        val c = open(url)
        try { return c.inputStream.use { String(it.readBytes(), Charsets.UTF_8) } } finally { c.disconnect() }
    }

    /** Blocking; call from a background thread. */
    fun download(ctx: Context) {
        if (busy) return
        busy = true
        try {
            status = "در حال دریافت فهرست نسخه‌ها از Mojang…"
            val manifest = JSONObject(getText(MANIFEST))
            val versions = manifest.getJSONArray("versions")
            var versionUrl: String? = null
            for (i in 0 until versions.length()) {
                val v = versions.getJSONObject(i)
                if (v.getString("id") == VERSION) { versionUrl = v.getString("url"); break }
            }
            if (versionUrl == null) throw IllegalStateException("نسخهٔ $VERSION پیدا نشد")
            val meta = JSONObject(getText(versionUrl))
            val jarUrl = meta.getJSONObject("downloads").getJSONObject("client").getString("url")

            val base = dir(ctx)
            base.mkdirs()
            val jar = File(base, "client.jar.tmp")
            val c = open(jarUrl)
            try {
                val total = c.contentLengthLong
                c.inputStream.use { ins ->
                    jar.outputStream().use { outs ->
                        val buf = ByteArray(32768)
                        var done = 0L
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            outs.write(buf, 0, n)
                            done += n
                            if (total > 0) status = "در حال دانلود فونت و تکسچرها… ${done * 100 / total}٪"
                        }
                    }
                }
            } finally { c.disconnect() }

            status = "در حال استخراج فایل‌ها…"
            val canonicalBase = base.canonicalPath
            ZipInputStream(jar.inputStream().buffered()).use { zin ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    if (e.isDirectory) continue
                    val name = e.name
                    if (KEEP_PREFIXES.none { name.startsWith(it) }) continue
                    val out = File(base, name)
                    if (!out.canonicalPath.startsWith(canonicalBase)) continue
                    out.parentFile?.mkdirs()
                    out.outputStream().use { zin.copyTo(it) }
                }
            }
            jar.delete()
            status = "فونت و تکسچرهای ماینکرافت آماده است"
            McFont.reload(ctx)
        } catch (e: Exception) {
            status = "دانلود ناموفق بود: ${e.message ?: e.javaClass.simpleName}"
        } finally {
            busy = false
        }
    }
}
