package com.mcclient.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val Scheme = darkColorScheme(
    primary = Color(0xFF6FCF76),
    onPrimary = Color(0xFF06220B),
    secondary = Color(0xFF9AD0A0),
    background = Color(0xFF0F1311),
    onBackground = Color(0xFFE4EAE5),
    surface = Color(0xFF181D1A),
    onSurface = Color(0xFFE4EAE5),
    surfaceVariant = Color(0xFF232A26),
    onSurfaceVariant = Color(0xFFB4BDB6),
    error = Color(0xFFFF6B6B),
    outline = Color(0xFF3B453F)
)

@Composable
fun McTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { content() }
    }
}
