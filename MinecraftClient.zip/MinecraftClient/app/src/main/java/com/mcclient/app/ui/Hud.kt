package com.mcclient.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val HEART = arrayOf(
    ".OO...OO.",
    "ORHO.ORRO",
    "ORRRORRRO",
    "ORRRRRRRO",
    ".ORRRRRO.",
    "..ORRRO..",
    "...ORO...",
    "....O....",
    "........."
)

private val DRUMSTICK = arrayOf(
    "......OO.",
    "....OOBBO",
    "...OBBHBO",
    "..OBBBBBO",
    "..OBBBBO.",
    ".OWOBBO..",
    "OWWOOO...",
    "OWOO.....",
    ".OO......"
)

private fun px(c: Long) = Color(c)

private fun iconColor(ch: Char, kind: Int, filled: Boolean): Color? = when (ch) {
    'O' -> px(0xFF2A0A0A)
    'R' -> if (filled) px(0xFFE41B1B) else px(0xFF3A2A2A)
    'H' -> if (filled) px(0xFFFF9B9B) else px(0xFF3A2A2A)
    'B' -> if (filled) px(0xFFB5651D) else px(0xFF3A3028)
    'W' -> if (filled) px(0xFFEDEDED) else px(0xFF4A4A4A)
    else -> null
}.let { c ->
    if (c != null && kind == 1 && ch == 'O') px(0xFF2B1A0A) else c
}

@Composable
private fun Icon9(art: Array<String>, kind: Int, state: Int, sizeDp: Int) {
    // state: 2 = full, 1 = half (left half filled), 0 = empty
    Canvas(Modifier.size(sizeDp.dp)) {
        val u = size.width / 9f
        for (y in 0 until 9) for (x in 0 until 9) {
            val ch = art[y][x]
            val filled = state == 2 || (state == 1 && x <= 4)
            val col = iconColor(ch, kind, filled) ?: continue
            drawRect(col, Offset(x * u, y * u), Size(u + 0.5f, u + 0.5f))
        }
    }
}

/** Ten hearts for 20 health points, like the vanilla HUD. */
@Composable
fun Hearts(health: Float, sizeDp: Int = 16) {
    Row(horizontalArrangement = Arrangement.spacedBy(1.dp)) {
        val hp = health.coerceIn(0f, 20f)
        for (i in 0 until 10) {
            val v = hp - i * 2f
            Icon9(HEART, 0, if (v >= 2f) 2 else if (v >= 1f) 1 else 0, sizeDp)
        }
    }
}

/** Ten drumsticks for 20 hunger points. */
@Composable
fun Hunger(food: Int, sizeDp: Int = 16) {
    Row(horizontalArrangement = Arrangement.spacedBy(1.dp)) {
        val f = food.coerceIn(0, 20)
        for (i in 0 until 10) {
            val v = f - i * 2
            Icon9(DRUMSTICK, 1, if (v >= 2) 2 else if (v >= 1) 1 else 0, sizeDp)
        }
    }
}
